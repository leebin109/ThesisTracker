/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakToggle */
const { useState } = React;

// ──────────────────────────────────────────────────────────
// Sketch primitives
// ──────────────────────────────────────────────────────────
const wfStyles = {
  ink: '#1a1a1a',
  ink2: '#2a2a2a',
  paper: '#f4ede0',  // warm cream
  paper2: '#ebe2d0',
  pencil: '#3a3a3a',
  faint: '#9a9080',
  amber: '#d97706',  // Bloomberg amber
  cyan: '#0891b2',
  green: '#15803d',
  red: '#b91c1c',
  hand: "'Kalam', 'Caveat', cursive",
  mono: "'JetBrains Mono', ui-monospace, monospace",
};

// Sketchy box: dashed/wobbly border using SVG filter for hand-drawn feel
const Box = ({ children, style, dashed, fill, accent, label, ...rest }) => (
  <div
    style={{
      position: 'relative',
      border: `1.5px ${dashed ? 'dashed' : 'solid'} ${accent || wfStyles.pencil}`,
      borderRadius: 3,
      background: fill || 'transparent',
      padding: 8,
      fontFamily: wfStyles.mono,
      fontSize: 11,
      color: wfStyles.ink,
      ...style,
    }}
    {...rest}
  >
    {label && (
      <div style={{
        position: 'absolute', top: -8, left: 8,
        background: wfStyles.paper, padding: '0 6px',
        fontFamily: wfStyles.hand, fontSize: 12, fontWeight: 700,
        color: accent || wfStyles.pencil,
      }}>{label}</div>
    )}
    {children}
  </div>
);

const Hand = ({ children, size = 14, color, style }) => (
  <span style={{ fontFamily: wfStyles.hand, fontSize: size, color: color || wfStyles.pencil, ...style }}>
    {children}
  </span>
);

const Mono = ({ children, size = 10, color, weight, style }) => (
  <span style={{ fontFamily: wfStyles.mono, fontSize: size, color: color || wfStyles.ink, fontWeight: weight || 400, ...style }}>
    {children}
  </span>
);

const Squiggle = ({ width = 100, height = 8, color = wfStyles.faint }) => (
  <svg width={width} height={height} style={{ display: 'block' }}>
    <path
      d={`M 2 ${height/2} Q ${width*0.15} 1 ${width*0.3} ${height/2} T ${width*0.6} ${height/2} T ${width*0.9} ${height/2}`}
      fill="none" stroke={color} strokeWidth="1.2" strokeLinecap="round"
    />
  </svg>
);

const ChartSketch = ({ width = '100%', height = 80, accent = wfStyles.amber }) => (
  <svg viewBox="0 0 200 80" preserveAspectRatio="none" style={{ width, height, display: 'block' }}>
    <defs>
      <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
        <path d="M 20 0 L 0 0 0 20" fill="none" stroke={wfStyles.faint} strokeWidth="0.4" opacity="0.4"/>
      </pattern>
    </defs>
    <rect width="200" height="80" fill="url(#grid)" />
    <path d="M 0 60 L 15 55 L 30 58 L 45 50 L 60 45 L 75 48 L 90 38 L 105 42 L 120 32 L 135 35 L 150 25 L 165 28 L 180 18 L 200 22"
      fill="none" stroke={accent} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M 0 60 L 15 55 L 30 58 L 45 50 L 60 45 L 75 48 L 90 38 L 105 42 L 120 32 L 135 35 L 150 25 L 165 28 L 180 18 L 200 22 L 200 80 L 0 80 Z"
      fill={accent} opacity="0.08" />
  </svg>
);

const Sparkline = ({ width = 80, height = 18, accent = wfStyles.green }) => (
  <svg viewBox="0 0 80 18" style={{ width, height, display: 'block' }}>
    <path d="M 2 12 L 12 10 L 22 13 L 32 8 L 42 9 L 52 5 L 62 7 L 72 3"
      fill="none" stroke={accent} strokeWidth="1.4" strokeLinecap="round"/>
  </svg>
);

const Bar = ({ pct = 60, color = wfStyles.amber, w = 80 }) => (
  <svg width={w} height={6}>
    <rect x="0" y="2" width={w} height="2" fill={wfStyles.faint} opacity="0.4" />
    <rect x="0" y="1" width={w * pct / 100} height="4" fill={color} rx="1" />
  </svg>
);

const Ring = ({ score = 72, size = 44, accent = wfStyles.amber }) => {
  const r = size / 2 - 3;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} style={{ display: 'block' }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={wfStyles.faint} strokeWidth="2.5" opacity="0.4"/>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={accent} strokeWidth="2.5"
        strokeDasharray={`${c * score / 100} ${c}`} strokeLinecap="round"
        transform={`rotate(-90 ${size/2} ${size/2})`}/>
      <text x="50%" y="54%" textAnchor="middle" fontFamily={wfStyles.mono} fontSize={size*0.32} fontWeight="700" fill={wfStyles.ink}>{score}</text>
    </svg>
  );
};

const Annotation = ({ children, side = 'right', color = wfStyles.amber, style }) => (
  <div style={{
    fontFamily: wfStyles.hand, fontSize: 13, color, lineHeight: 1.2,
    display: 'flex', alignItems: 'center', gap: 4, ...style,
  }}>
    {side === 'left' && <span>↗</span>}
    <span>{children}</span>
    {side === 'right' && <span>↙</span>}
  </div>
);

// ──────────────────────────────────────────────────────────
// V1 — Classic Bloomberg Multi-Pane (4-quadrant)
// ──────────────────────────────────────────────────────────
const V1 = ({ density }) => {
  const pad = density === 'tight' ? 4 : density === 'loose' ? 12 : 8;
  return (
    <div style={{ width: 1280, height: 800, background: wfStyles.paper, padding: 16, fontFamily: wfStyles.mono, position: 'relative' }}>
      {/* Top command bar */}
      <Box style={{ display: 'grid', gridTemplateColumns: '160px 1fr 200px 120px', gap: 12, padding: 8, marginBottom: pad }} fill={wfStyles.paper2}>
        <Mono size={12} weight={700}>THESISTRACK ▮</Mono>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <Mono size={10} color={wfStyles.faint}>CMD&gt;</Mono>
          <Mono size={11}>TSLA US EQUITY ▮</Mono>
          <Hand size={11} color={wfStyles.faint}>(ticker / company / 매수의견 명령)</Hand>
        </div>
        <Mono size={10} color={wfStyles.faint}>16:42:08 KST · 5월 7일</Mono>
        <Mono size={10} color={wfStyles.amber}>● LIVE · DART · FMP</Mono>
      </Box>

      {/* Ticker rail */}
      <Box style={{ display: 'flex', gap: 14, padding: '6px 10px', marginBottom: pad, overflow: 'hidden' }} fill={wfStyles.paper2}>
        {['TSLA 253.40 +1.2%', 'AAPL 212.05 -0.4%', '005930 76,400 +0.8%', 'NVDA 142.18 +2.1%', 'KOSPI 2,712 +0.5%', 'S&P 5,182 +0.2%'].map((t, i) => (
          <Mono key={i} size={10} color={i % 3 === 1 ? wfStyles.red : wfStyles.green}>{t}</Mono>
        ))}
      </Box>

      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr 240px', gap: pad, height: 660 }}>
        {/* Left rail */}
        <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr auto', gap: pad, minHeight: 0 }}>
          <Box label="SEARCH" style={{ padding: 10 }}>
            <Mono size={10} color={wfStyles.faint}>회사명 / 티커</Mono>
            <div style={{ borderBottom: `1px solid ${wfStyles.pencil}`, marginTop: 4, paddingBottom: 2 }}>
              <Mono size={11}>NVDA▮</Mono>
            </div>
          </Box>
          <Box label="WATCHLIST · 8" style={{ overflow: 'hidden', padding: 6 }}>
            {[
              ['TSLA', 'Tesla', 44, '+1.2', wfStyles.green],
              ['AAPL', 'Apple', 68, '-0.4', wfStyles.red],
              ['005930', '삼성전자', 71, '+0.8', wfStyles.green],
              ['NVDA', 'NVIDIA', 82, '+2.1', wfStyles.green],
              ['7203', 'Toyota', 65, '+0.3', wfStyles.green],
              ['MSFT', 'Microsoft', 75, '0.0', wfStyles.faint],
              ['000660', 'SK하이닉스', 69, '+1.5', wfStyles.green],
              ['META', 'Meta', 58, '-1.1', wfStyles.red],
            ].map(([t, n, s, d, c], i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '52px 1fr 28px 36px',
                gap: 6, padding: '4px 2px', alignItems: 'center',
                background: i === 0 ? wfStyles.amber + '22' : 'transparent',
                borderLeft: i === 0 ? `2px solid ${wfStyles.amber}` : '2px solid transparent',
              }}>
                <Mono size={10} weight={700}>{t}</Mono>
                <Mono size={9} color={wfStyles.faint} style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{n}</Mono>
                <Mono size={9} weight={700} color={s > 60 ? wfStyles.green : wfStyles.amber}>{s}</Mono>
                <Mono size={9} color={c}>{d}%</Mono>
              </div>
            ))}
          </Box>
          <Box label="DATA SRC" style={{ padding: 8 }} dashed>
            <Mono size={9} color={wfStyles.faint}>● ALPHAVAN · ● DART · ● FMP</Mono>
            <Mono size={9} color={wfStyles.faint} style={{ display: 'block', marginTop: 4 }}>cache 3d · settings ▸</Mono>
          </Box>
        </div>

        {/* Center 4-quadrant */}
        <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr 1fr', gap: pad, minHeight: 0 }}>
          {/* Hero strip */}
          <Box fill={wfStyles.paper2} style={{ padding: 12 }} accent={wfStyles.amber}>
            <div style={{ display: 'grid', gridTemplateColumns: '60px 1fr auto auto', gap: 14, alignItems: 'center' }}>
              <Ring score={44} size={56} accent={wfStyles.amber} />
              <div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
                  <Mono size={16} weight={700}>TSLA</Mono>
                  <Mono size={11} color={wfStyles.faint}>Tesla, Inc · NASDAQ · USD</Mono>
                  <Mono size={9} color={wfStyles.amber} style={{ border: `1px solid ${wfStyles.amber}`, padding: '1px 5px', borderRadius: 2 }}>WATCH</Mono>
                </div>
                <Hand size={14} style={{ display: 'block', marginTop: 4 }}>
                  "전기차 마진보다 자율주행과 에너지 사업의 실제 확인이 핵심"
                </Hand>
              </div>
              <div style={{ textAlign: 'right' }}>
                <Mono size={18} weight={700}>$253.40</Mono>
                <Mono size={10} color={wfStyles.green} style={{ display: 'block' }}>+3.04 (+1.21%)</Mono>
              </div>
              <div style={{ textAlign: 'right', borderLeft: `1px dashed ${wfStyles.faint}`, paddingLeft: 14 }}>
                <Mono size={9} color={wfStyles.faint}>TGT $280 · 상승여력</Mono>
                <Mono size={14} weight={700} color={wfStyles.green} style={{ display: 'block' }}>+10.5%</Mono>
              </div>
            </div>
          </Box>

          {/* Chart */}
          <Box label="PX · 1Y · CANDLES" style={{ padding: '14px 8px 8px', minHeight: 0 }}>
            <div style={{ display: 'flex', gap: 6, marginBottom: 4 }}>
              {['1D','5D','1M','3M','6M','1Y','5Y'].map((p, i) => (
                <Mono key={i} size={9} color={i === 5 ? wfStyles.amber : wfStyles.faint}
                  style={{ padding: '1px 5px', border: `1px solid ${i === 5 ? wfStyles.amber : 'transparent'}`, borderRadius: 2 }}>{p}</Mono>
              ))}
              <div style={{ flex: 1 }}/>
              <Mono size={9} color={wfStyles.faint}>OHLC · VOL · MA50 · MA200</Mono>
            </div>
            <ChartSketch height={130} />
          </Box>

          {/* Bottom row: scores | quality */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: pad, minHeight: 0 }}>
            <Box label="SCORE BREAKDOWN" style={{ padding: 10 }}>
              {[
                ['수익성 PROFIT', 41, wfStyles.amber],
                ['안정성 STABIL', 88, wfStyles.green],
                ['성장성 GROWTH', 24, wfStyles.red],
                ['밸류에이션 VAL', 0, wfStyles.red],
                ['리스크 RISK', 78, wfStyles.green],
              ].map(([l, p, c], i) => (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '110px 1fr 32px', gap: 8, alignItems: 'center', padding: '3px 0' }}>
                  <Mono size={9}>{l}</Mono>
                  <Bar pct={p} color={c} w={140} />
                  <Mono size={10} weight={700} color={c}>{p}</Mono>
                </div>
              ))}
              <Hand size={11} color={wfStyles.amber} style={{ marginTop: 6, display: 'block' }}>
                ↳ 가중치는 우측 'MODEL' 패널에서 즉시 조정
              </Hand>
            </Box>
            <Box label="DATA QUALITY" style={{ padding: 10 }}>
              {[
                ['● 재무 기준일 2025-12-31', wfStyles.green],
                ['◐ EPS 성장 데이터 6개월 경과', wfStyles.amber],
                ['● 가격 출처 FMP · 실시간', wfStyles.green],
                ['◐ HBM 매출 비공식 추정', wfStyles.amber],
                ['● 다음 리뷰 5월 31일 (D-24)', wfStyles.cyan],
              ].map(([t, c], i) => (
                <Mono key={i} size={10} color={c} style={{ display: 'block', padding: '2px 0' }}>{t}</Mono>
              ))}
            </Box>
          </div>
        </div>

        {/* Right rail: pitch + history */}
        <div style={{ display: 'grid', gridTemplateRows: '1fr auto auto', gap: pad, minHeight: 0 }}>
          <Box label="PITCH · THESIS" style={{ padding: 10, overflow: 'hidden' }}>
            <Mono size={9} color={wfStyles.faint}>핵심 질문</Mono>
            <Mono size={10} style={{ display: 'block', marginTop: 2, marginBottom: 8, lineHeight: 1.4 }}>
              FSD와 ESS가 자동차 마진 둔화를 상쇄할 수 있는가?
            </Mono>
            <Mono size={9} color={wfStyles.faint}>Thesis</Mono>
            <Squiggle width={200} />
            <Squiggle width={180} />
            <Squiggle width={210} />
            <Mono size={9} color={wfStyles.faint} style={{ marginTop: 8 }}>Catalyst</Mono>
            <Squiggle width={170} />
            <Squiggle width={190} />
            <Mono size={9} color={wfStyles.faint} style={{ marginTop: 8 }}>Risk</Mono>
            <Squiggle width={200} />
            <Squiggle width={150} />
            <Mono size={9} color={wfStyles.faint} style={{ marginTop: 8 }}>Variant View</Mono>
            <Squiggle width={180} />
          </Box>
          <Box label="VAL · BULL/BASE/BEAR" style={{ padding: 8 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 4, textAlign: 'center' }}>
              {[['BEAR', 135, wfStyles.red], ['BASE', 280, wfStyles.amber], ['BULL', 425, wfStyles.green]].map(([l, p, c], i) => (
                <div key={i} style={{ border: `1px solid ${c}`, padding: 4 }}>
                  <Mono size={9} color={c} weight={700}>{l}</Mono>
                  <Mono size={11} weight={700} style={{ display: 'block' }}>${p}</Mono>
                </div>
              ))}
            </div>
          </Box>
          <Box label="SCORE HX" style={{ padding: 8 }}>
            <Sparkline width={210} height={32} accent={wfStyles.amber} />
            <Mono size={9} color={wfStyles.faint}>1y · 12 snapshots · σ 11.4</Mono>
          </Box>
        </div>
      </div>

      {/* Annotations */}
      <Annotation style={{ position: 'absolute', top: 76, left: 1100, width: 170, transform: 'rotate(-3deg)' }}>
        티커 rail = 한눈에 시장 맥락
      </Annotation>
      <Annotation side="left" style={{ position: 'absolute', top: 200, left: 250, width: 200, transform: 'rotate(2deg)' }} color={wfStyles.cyan}>
        WATCHLIST의 active 항목은 amber 막대로
      </Annotation>
      <Annotation style={{ position: 'absolute', top: 400, left: 1090, width: 180, transform: 'rotate(2deg)' }} color={wfStyles.cyan}>
        Pitch는 항상 우측 고정 — 스크롤 없음
      </Annotation>
    </div>
  );
};

// ──────────────────────────────────────────────────────────
// V2 — Tabbed Workspace (Overview / Pitch / Valuation / Peer / History)
// ──────────────────────────────────────────────────────────
const V2 = ({ density }) => {
  const pad = density === 'tight' ? 4 : density === 'loose' ? 12 : 8;
  const tabs = ['OVERVIEW', 'PITCH', 'VALUATION', 'PEERS', 'HISTORY', 'NOTES'];
  return (
    <div style={{ width: 1280, height: 800, background: wfStyles.paper, padding: 16, fontFamily: wfStyles.mono, position: 'relative' }}>
      {/* Top bar with global ticker */}
      <Box style={{ display: 'grid', gridTemplateColumns: '180px 1fr 280px', gap: 14, padding: 8, marginBottom: pad }} fill={wfStyles.paper2}>
        <Mono size={12} weight={700} color={wfStyles.amber}>▮ THESIS//TRACK</Mono>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center', overflow: 'hidden' }}>
          {['TSLA 253.4 ▲', 'AAPL 212.0 ▼', '005930 76,400 ▲', 'NVDA 142.2 ▲', 'KOSPI 2712 ▲'].map((t, i) => (
            <Mono key={i} size={9} color={i === 1 ? wfStyles.red : wfStyles.green}>{t}</Mono>
          ))}
        </div>
        <Mono size={9} color={wfStyles.faint} style={{ textAlign: 'right' }}>16:42 KST · DART · FMP · ALPHA</Mono>
      </Box>

      <div style={{ display: 'grid', gridTemplateColumns: '230px 1fr', gap: pad, height: 700 }}>
        {/* Left watchlist */}
        <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr', gap: pad, minHeight: 0 }}>
          <Box label="SEARCH / ADD" style={{ padding: 8 }}>
            <div style={{ borderBottom: `1px solid ${wfStyles.pencil}`, paddingBottom: 4, marginBottom: 4 }}>
              <Mono size={10}>회사명 또는 티커 ▮</Mono>
            </div>
            <Mono size={9} color={wfStyles.faint}>FMP / Yahoo 보조검색</Mono>
          </Box>
          <Box label="WATCHLIST" style={{ padding: 6, overflow: 'hidden' }}>
            <div style={{ display: 'flex', gap: 4, marginBottom: 6 }}>
              {['ALL','★','SCORE↓','REVIEW'].map((c, i) => (
                <Mono key={i} size={9} color={i === 0 ? wfStyles.amber : wfStyles.faint}
                  style={{ padding: '1px 5px', border: `1px solid ${i === 0 ? wfStyles.amber : wfStyles.faint}`, borderRadius: 2 }}>{c}</Mono>
              ))}
            </div>
            {[
              ['TSLA', 'Tesla', 44, '$253.40', '+1.2'],
              ['AAPL', 'Apple', 68, '$212.05', '-0.4'],
              ['005930', '삼성전자', 71, '₩76,400', '+0.8'],
              ['NVDA', 'NVIDIA', 82, '$142.18', '+2.1'],
              ['7203', 'Toyota', 65, '¥2,847', '+0.3'],
              ['MSFT', 'Microsoft', 75, '$418.20', '0.0'],
              ['META', 'Meta', 58, '$521.40', '-1.1'],
            ].map(([t, n, s, p, d], i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '1fr auto', gap: 4, padding: '5px 4px',
                background: i === 0 ? wfStyles.amber + '22' : 'transparent',
                borderLeft: i === 0 ? `2px solid ${wfStyles.amber}` : '2px solid transparent',
                marginBottom: 2,
              }}>
                <div>
                  <Mono size={10} weight={700}>{t}</Mono>
                  <Mono size={8} color={wfStyles.faint} style={{ display: 'block' }}>{n}</Mono>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <Mono size={9}>{p}</Mono>
                  <Mono size={8} color={Number(d) > 0 ? wfStyles.green : Number(d) < 0 ? wfStyles.red : wfStyles.faint} style={{ display: 'block' }}>{d}% · {s}</Mono>
                </div>
              </div>
            ))}
          </Box>
        </div>

        {/* Right: tabbed workspace */}
        <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto 1fr', gap: pad, minHeight: 0 }}>
          {/* Header */}
          <Box style={{ padding: 12, display: 'grid', gridTemplateColumns: 'auto 1fr auto auto auto', gap: 14, alignItems: 'center' }} fill={wfStyles.paper2}>
            <Ring score={44} size={56} accent={wfStyles.amber} />
            <div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
                <Mono size={20} weight={700}>TSLA</Mono>
                <Mono size={11} color={wfStyles.faint}>Tesla, Inc · NASDAQ</Mono>
              </div>
              <Hand size={15} style={{ display: 'block', marginTop: 2 }}>
                "전기차 마진보다 자율주행과 에너지 사업의 실제 확인이 핵심"
              </Hand>
            </div>
            <div style={{ textAlign: 'right' }}>
              <Mono size={9} color={wfStyles.faint}>현재가</Mono>
              <Mono size={16} weight={700} style={{ display: 'block' }}>$253.40</Mono>
              <Mono size={9} color={wfStyles.green}>+3.04 (+1.21%)</Mono>
            </div>
            <div style={{ textAlign: 'right', borderLeft: `1px dashed ${wfStyles.faint}`, paddingLeft: 14 }}>
              <Mono size={9} color={wfStyles.faint}>목표가</Mono>
              <Mono size={16} weight={700} style={{ display: 'block' }}>$280</Mono>
              <Mono size={9} color={wfStyles.green}>+10.5%</Mono>
            </div>
            <div style={{ display: 'grid', gap: 4 }}>
              <Mono size={9} color={wfStyles.amber} style={{ border: `1px solid ${wfStyles.amber}`, padding: '2px 8px', borderRadius: 2, textAlign: 'center' }}>WATCH ▾</Mono>
              <Mono size={9} color={wfStyles.cyan} style={{ border: `1px solid ${wfStyles.cyan}`, padding: '2px 8px', borderRadius: 2, textAlign: 'center' }}>SAVE</Mono>
            </div>
          </Box>

          {/* Tab bar */}
          <Box style={{ padding: 0, borderBottom: `2px solid ${wfStyles.pencil}`, border: 'none', display: 'flex', gap: 0 }}>
            {tabs.map((t, i) => (
              <div key={i} style={{
                padding: '8px 16px',
                borderBottom: i === 0 ? `3px solid ${wfStyles.amber}` : `3px solid transparent`,
                background: i === 0 ? wfStyles.paper2 : 'transparent',
              }}>
                <Mono size={11} weight={i === 0 ? 700 : 400} color={i === 0 ? wfStyles.amber : wfStyles.ink}>{t}</Mono>
              </div>
            ))}
            <div style={{ flex: 1, borderBottom: `2px solid ${wfStyles.pencil}` }}/>
            <Mono size={9} color={wfStyles.faint} style={{ padding: '10px 8px' }}>가격만 ▸ 재무만 ▸ 전체갱신</Mono>
          </Box>

          {/* Sub-tab indicator */}
          <Mono size={9} color={wfStyles.faint}>OVERVIEW · 건강검진 + 차트 + 점수 분해 + 데이터 점검 한눈에</Mono>

          {/* Tab content: OVERVIEW */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: pad, minHeight: 0 }}>
            <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr', gap: pad, minHeight: 0 }}>
              <Box label="PRICE · 1Y" style={{ padding: '14px 8px 8px' }}>
                <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
                  {['1D','1M','3M','1Y','5Y','MAX'].map((p, i) => (
                    <Mono key={i} size={9} color={i === 3 ? wfStyles.amber : wfStyles.faint}
                      style={{ padding: '1px 5px', border: `1px solid ${i === 3 ? wfStyles.amber : 'transparent'}`, borderRadius: 2 }}>{p}</Mono>
                  ))}
                  <div style={{ flex: 1 }}/>
                  <Mono size={9} color={wfStyles.cyan}>+ COMPARE PEERS</Mono>
                </div>
                <ChartSketch height={140} />
              </Box>
              <Box label="KEY METRICS" style={{ padding: 10 }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
                  {[
                    ['PER', '72.6x', wfStyles.amber], ['PBR', '9.8x', wfStyles.amber],
                    ['ROE', '12.1%', wfStyles.green], ['영업마진', '7.4%', wfStyles.amber],
                    ['부채비율', '17%', wfStyles.green], ['매출성장', '+8.7%', wfStyles.green],
                    ['EPS성장', '-22.4%', wfStyles.red], ['FCF마진', '4.8%', wfStyles.amber],
                  ].map(([l, v, c], i) => (
                    <div key={i} style={{ borderLeft: `2px solid ${c}`, paddingLeft: 6 }}>
                      <Mono size={8} color={wfStyles.faint}>{l}</Mono>
                      <Mono size={13} weight={700} color={c} style={{ display: 'block' }}>{v}</Mono>
                      <Mono size={7} color={wfStyles.faint}>2025-12-31 · SEC</Mono>
                    </div>
                  ))}
                </div>
              </Box>
            </div>
            <div style={{ display: 'grid', gridTemplateRows: '1fr auto', gap: pad, minHeight: 0 }}>
              <Box label="SCORE · 5 PILLARS" style={{ padding: 10 }}>
                {[
                  ['수익성', 41, wfStyles.amber, 25],
                  ['안정성', 88, wfStyles.green, 25],
                  ['성장성', 24, wfStyles.red, 20],
                  ['밸류에이션', 0, wfStyles.red, 20],
                  ['리스크', 78, wfStyles.green, 10],
                ].map(([l, p, c, w], i) => (
                  <div key={i} style={{ display: 'grid', gridTemplateColumns: '70px 1fr 24px 30px', gap: 6, alignItems: 'center', padding: '4px 0' }}>
                    <Mono size={10}>{l}</Mono>
                    <Bar pct={p} color={c} w={120} />
                    <Mono size={10} weight={700} color={c}>{p}</Mono>
                    <Mono size={8} color={wfStyles.faint}>{w}%</Mono>
                  </div>
                ))}
                <div style={{ borderTop: `1px dashed ${wfStyles.faint}`, marginTop: 8, paddingTop: 6 }}>
                  <Mono size={9} color={wfStyles.faint}>SIGNAL</Mono>
                  <Hand size={12} style={{ display: 'block' }}>밸류에이션 부담 — Watch 유지</Hand>
                </div>
              </Box>
              <Box label="QUALITY · 5" style={{ padding: 8 }}>
                <Mono size={9} color={wfStyles.green} style={{ display: 'block' }}>● 가격 실시간</Mono>
                <Mono size={9} color={wfStyles.amber} style={{ display: 'block' }}>◐ EPS 6개월 경과</Mono>
                <Mono size={9} color={wfStyles.cyan} style={{ display: 'block' }}>● 다음 리뷰 D-24</Mono>
              </Box>
            </div>
          </div>
        </div>
      </div>

      <Annotation style={{ position: 'absolute', top: 130, left: 1080, width: 200, transform: 'rotate(-2deg)' }}>
        탭으로 9개 패널을 5-6개로 묶음
      </Annotation>
      <Annotation side="left" style={{ position: 'absolute', top: 240, left: 290, width: 200, transform: 'rotate(2deg)' }} color={wfStyles.cyan}>
        헤더 = 의사결정 요약 zone
      </Annotation>
    </div>
  );
};

// ──────────────────────────────────────────────────────────
// V3 — Master-Detail (left summary + right deep-dive)
// ──────────────────────────────────────────────────────────
const V3 = ({ density }) => {
  const pad = density === 'tight' ? 4 : density === 'loose' ? 12 : 8;
  return (
    <div style={{ width: 1280, height: 800, background: wfStyles.paper, padding: 16, fontFamily: wfStyles.mono, position: 'relative' }}>
      {/* Compact top */}
      <Box style={{ padding: 6, marginBottom: pad, display: 'grid', gridTemplateColumns: '160px 1fr auto', gap: 12 }} fill={wfStyles.paper2}>
        <Mono size={11} weight={700} color={wfStyles.amber}>▮ THESIS//TRACK</Mono>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', overflow: 'hidden' }}>
          <Mono size={9} color={wfStyles.faint}>CMD&gt;</Mono>
          <Mono size={10}>TSLA ▮</Mono>
          <Mono size={8} color={wfStyles.faint}>· tab/↑↓ navigate</Mono>
        </div>
        <Mono size={9} color={wfStyles.faint}>16:42 KST</Mono>
      </Box>

      <div style={{ display: 'grid', gridTemplateColumns: '180px 360px 1fr', gap: pad, height: 720 }}>
        {/* Watchlist (compact) */}
        <Box label="WATCH · 8" style={{ padding: 4, overflow: 'hidden' }}>
          {[
            ['TSLA', 44, true],
            ['AAPL', 68, false],
            ['005930', 71, false],
            ['NVDA', 82, false],
            ['7203', 65, false],
            ['MSFT', 75, false],
            ['000660', 69, false],
            ['META', 58, false],
            ['JPM', 73, false],
          ].map(([t, s, active], i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 4, padding: '4px 6px',
              background: active ? wfStyles.amber + '22' : 'transparent',
              borderLeft: active ? `2px solid ${wfStyles.amber}` : '2px solid transparent',
            }}>
              <Mono size={10} weight={active ? 700 : 400}>{t}</Mono>
              <Sparkline width={36} height={10} accent={s > 60 ? wfStyles.green : wfStyles.amber} />
              <Mono size={9} weight={700} color={s > 60 ? wfStyles.green : wfStyles.amber}>{s}</Mono>
            </div>
          ))}
        </Box>

        {/* Master: persistent summary card */}
        <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto auto 1fr', gap: pad, minHeight: 0 }}>
          <Box style={{ padding: 12 }} fill={wfStyles.paper2} accent={wfStyles.amber}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <Ring score={44} size={64} accent={wfStyles.amber} />
              <div style={{ flex: 1 }}>
                <Mono size={18} weight={700}>TSLA</Mono>
                <Mono size={9} color={wfStyles.faint} style={{ display: 'block' }}>Tesla, Inc · NASDAQ · USD</Mono>
                <Mono size={9} color={wfStyles.amber} style={{ display: 'inline-block', border: `1px solid ${wfStyles.amber}`, padding: '1px 6px', borderRadius: 2, marginTop: 4 }}>WATCH</Mono>
              </div>
            </div>
            <Hand size={14} style={{ display: 'block', marginTop: 10, lineHeight: 1.3 }}>
              "전기차 마진보다 FSD와 에너지 사업의 실제 확인이 핵심"
            </Hand>
          </Box>

          <Box style={{ padding: 10, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <Mono size={8} color={wfStyles.faint}>CURRENT</Mono>
              <Mono size={16} weight={700} style={{ display: 'block' }}>$253.40</Mono>
              <Mono size={9} color={wfStyles.green}>+1.21%</Mono>
            </div>
            <div style={{ borderLeft: `1px dashed ${wfStyles.faint}`, paddingLeft: 10 }}>
              <Mono size={8} color={wfStyles.faint}>TARGET · UPSIDE</Mono>
              <Mono size={16} weight={700} style={{ display: 'block' }}>$280</Mono>
              <Mono size={9} color={wfStyles.green}>+10.5%</Mono>
            </div>
          </Box>

          <Box label="MINI CHART" style={{ padding: 8 }}>
            <ChartSketch height={70} />
          </Box>

          <Box label="VAL · BULL/BASE/BEAR" style={{ padding: 8 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 4 }}>
              {[['BEAR', 135, wfStyles.red], ['BASE', 280, wfStyles.amber], ['BULL', 425, wfStyles.green]].map(([l, p, c], i) => (
                <div key={i} style={{ border: `1px solid ${c}`, padding: 4, textAlign: 'center' }}>
                  <Mono size={8} color={c} weight={700}>{l}</Mono>
                  <Mono size={11} weight={700} style={{ display: 'block' }}>${p}</Mono>
                </div>
              ))}
            </div>
          </Box>

          <Box style={{ padding: 8 }}>
            <Mono size={8} color={wfStyles.faint}>NEXT REVIEW</Mono>
            <Mono size={11} weight={700} color={wfStyles.cyan}>2026-05-31 · D-24</Mono>
            <Hand size={11} style={{ display: 'block', marginTop: 4 }}>
              에너지 매출, 자동차 마진, FSD 코멘트
            </Hand>
          </Box>

          <Box label="JUMP TO" style={{ padding: 8 }}>
            {['Pitch', 'Valuation', 'Peers', 'Metrics', 'History', 'Notes', 'Model'].map((s, i) => (
              <div key={i} style={{ padding: '4px 6px', background: i === 0 ? wfStyles.cyan + '22' : 'transparent', borderLeft: i === 0 ? `2px solid ${wfStyles.cyan}` : '2px solid transparent' }}>
                <Mono size={10} weight={i === 0 ? 700 : 400} color={i === 0 ? wfStyles.cyan : wfStyles.ink}>▸ {s}</Mono>
              </div>
            ))}
          </Box>
        </div>

        {/* Detail: focused panel */}
        <Box label="PITCH · DETAIL" style={{ padding: 14, overflow: 'hidden' }}>
          <Mono size={9} color={wfStyles.faint}>한 줄 PITCH</Mono>
          <Hand size={17} style={{ display: 'block', marginTop: 4, marginBottom: 12, lineHeight: 1.3 }}>
            "전기차 마진보다 자율주행과 에너지 사업의 실제 확인이 핵심이다."
          </Hand>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 12 }}>
            <div>
              <Mono size={9} color={wfStyles.faint}>핵심 질문 · KEY Q</Mono>
              <Box style={{ padding: 8, marginTop: 4, minHeight: 50 }} dashed>
                <Mono size={11}>FSD와 ESS가 자동차 마진 둔화를 상쇄할 수 있는가?</Mono>
              </Box>
            </div>
            <div>
              <Mono size={9} color={wfStyles.faint}>VARIANT VIEW</Mono>
              <Box style={{ padding: 8, marginTop: 4, minHeight: 50 }} dashed>
                <Mono size={11}>시장은 FSD 기대를 크게 반영하지만 에너지 부문 마진 기여는 덜 반영</Mono>
              </Box>
            </div>
          </div>

          <Mono size={9} color={wfStyles.faint}>INVESTMENT THESIS</Mono>
          <Box style={{ padding: 10, marginTop: 4, minHeight: 90 }}>
            <Mono size={11} style={{ lineHeight: 1.6, display: 'block' }}>1. 에너지 저장장치 매출이 성장 축으로 부상</Mono>
            <Mono size={11} style={{ lineHeight: 1.6, display: 'block' }}>2. FSD 기대가 밸류에이션을 지지하나 실적 기여는 확인 필요</Mono>
            <Mono size={11} style={{ lineHeight: 1.6, display: 'block' }}>3. 자동차 마진 안정화가 먼저 확인되어야 함</Mono>
          </Box>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 12 }}>
            <div>
              <Mono size={9} color={wfStyles.green}>● CATALYST</Mono>
              <Squiggle width={300} /><Squiggle width={280} /><Squiggle width={290} />
            </div>
            <div>
              <Mono size={9} color={wfStyles.red}>● RISK</Mono>
              <Squiggle width={300} /><Squiggle width={260} /><Squiggle width={290} />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 12 }}>
            <div>
              <Mono size={9} color={wfStyles.faint}>확인할 숫자</Mono>
              <Squiggle width={280} /><Squiggle width={260} />
            </div>
            <div>
              <Mono size={9} color={wfStyles.faint}>WHAT WOULD CHANGE MY MIND</Mono>
              <Squiggle width={280} /><Squiggle width={260} />
            </div>
          </div>
        </Box>
      </div>

      <Annotation style={{ position: 'absolute', top: 80, left: 220, width: 150, transform: 'rotate(-3deg)' }}>
        리스트 → 페르시스턴트 카드
      </Annotation>
      <Annotation side="left" style={{ position: 'absolute', top: 70, left: 600, width: 200, transform: 'rotate(2deg)' }} color={wfStyles.cyan}>
        Master = 항상 의사결정 컨텍스트
      </Annotation>
      <Annotation style={{ position: 'absolute', top: 250, left: 1110, width: 160, transform: 'rotate(-2deg)' }} color={wfStyles.amber}>
        Detail에 한 패널만, 깊게
      </Annotation>
    </div>
  );
};

// ──────────────────────────────────────────────────────────
// V4 — Command-Driven Max Density (single-page collapsible)
// ──────────────────────────────────────────────────────────
const V4 = ({ density }) => {
  const pad = density === 'tight' ? 2 : density === 'loose' ? 8 : 4;
  return (
    <div style={{ width: 1280, height: 800, background: wfStyles.paper, padding: 12, fontFamily: wfStyles.mono, position: 'relative' }}>
      {/* Command line */}
      <Box style={{ padding: '4px 8px', marginBottom: pad, display: 'grid', gridTemplateColumns: 'auto 1fr auto auto', gap: 10, alignItems: 'center' }} fill={wfStyles.ink} accent={wfStyles.amber}>
        <Mono size={11} weight={700} color={wfStyles.amber}>TT//</Mono>
        <Mono size={11} color={wfStyles.amber}>&gt; TSLA US ▮ <span style={{ color: '#666' }}>· press : for cmd · / search · ? help</span></Mono>
        <Mono size={9} color={wfStyles.cyan}>F1 OVR · F2 PITCH · F3 VAL · F4 PEER · F5 HX</Mono>
        <Mono size={9} color={wfStyles.faint}>16:42:08</Mono>
      </Box>

      {/* Hero: single dense decision strip */}
      <Box style={{ padding: 10, marginBottom: pad, display: 'grid', gridTemplateColumns: '50px 1fr 1fr 1fr 1fr 1fr 1fr', gap: 14, alignItems: 'center' }} fill={wfStyles.paper2}>
        <Ring score={44} size={48} accent={wfStyles.amber} />
        <div>
          <Mono size={14} weight={700}>TSLA</Mono>
          <Mono size={8} color={wfStyles.faint} style={{ display: 'block' }}>Tesla · NASDAQ · WATCH</Mono>
        </div>
        <div>
          <Mono size={8} color={wfStyles.faint}>PRICE</Mono>
          <Mono size={13} weight={700} style={{ display: 'block' }}>$253.40</Mono>
          <Mono size={9} color={wfStyles.green}>+1.21%</Mono>
        </div>
        <div>
          <Mono size={8} color={wfStyles.faint}>TGT · UPSIDE</Mono>
          <Mono size={13} weight={700} style={{ display: 'block' }}>$280</Mono>
          <Mono size={9} color={wfStyles.green}>+10.5%</Mono>
        </div>
        <div>
          <Mono size={8} color={wfStyles.faint}>BULL/BASE/BEAR</Mono>
          <Mono size={11} weight={700} style={{ display: 'block' }}>
            <span style={{ color: wfStyles.green }}>425</span> · <span style={{ color: wfStyles.amber }}>280</span> · <span style={{ color: wfStyles.red }}>135</span>
          </Mono>
          <Mono size={8} color={wfStyles.faint}>$/sh PER 70x</Mono>
        </div>
        <div>
          <Mono size={8} color={wfStyles.faint}>NEXT REVIEW</Mono>
          <Mono size={13} weight={700} color={wfStyles.cyan} style={{ display: 'block' }}>D-24</Mono>
          <Mono size={8} color={wfStyles.faint}>2026-05-31</Mono>
        </div>
        <div>
          <Mono size={8} color={wfStyles.faint}>SCORE TREND 12M</Mono>
          <Sparkline width={120} height={20} accent={wfStyles.amber} />
          <Mono size={8} color={wfStyles.faint}>52 → 44 (-8)</Mono>
        </div>
      </Box>

      {/* Hero pitch line */}
      <Box style={{ padding: '8px 12px', marginBottom: pad }} fill="transparent">
        <Hand size={18} style={{ lineHeight: 1.2 }}>
          "전기차 마진보다 자율주행과 에너지 사업의 실제 확인이 핵심"
        </Hand>
      </Box>

      <div style={{ display: 'grid', gridTemplateColumns: '180px 1fr 1fr', gap: pad, height: 580 }}>
        {/* Left: ultra-compact watchlist */}
        <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr auto', gap: pad, minHeight: 0 }}>
          <Box style={{ padding: 4 }} fill={wfStyles.paper2}>
            <Mono size={9} color={wfStyles.faint}>: SYMBOL ▮</Mono>
          </Box>
          <Box label="WATCH" style={{ padding: 2, overflow: 'hidden' }}>
            {[
              ['TSLA', 44, '+1.2', true], ['AAPL', 68, '-0.4', false],
              ['005930', 71, '+0.8', false], ['NVDA', 82, '+2.1', false],
              ['7203', 65, '+0.3', false], ['MSFT', 75, '0.0', false],
              ['000660', 69, '+1.5', false], ['META', 58, '-1.1', false],
              ['JPM', 73, '+0.4', false], ['GOOG', 80, '+0.9', false],
              ['AMZN', 71, '-0.2', false], ['BHP', 62, '+1.1', false],
            ].map(([t, s, d, a], i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 3, padding: '2px 4px',
                background: a ? wfStyles.amber + '22' : 'transparent',
              }}>
                <Mono size={9} weight={a ? 700 : 400}>{t}</Mono>
                <Mono size={8} weight={700} color={s > 60 ? wfStyles.green : wfStyles.amber}>{s}</Mono>
                <Mono size={8} color={Number(d) > 0 ? wfStyles.green : Number(d) < 0 ? wfStyles.red : wfStyles.faint}>{d}</Mono>
              </div>
            ))}
          </Box>
          <Box dashed style={{ padding: 4 }}>
            <Mono size={8} color={wfStyles.faint}>● DART ● FMP ● ALPHA</Mono>
          </Box>
        </div>

        {/* Center: scrollable stacked sections */}
        <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: pad, minHeight: 0 }}>
          <Box label="◢ CHART · 1Y" style={{ padding: '12px 6px 4px' }}>
            <ChartSketch height={120} />
            <Mono size={8} color={wfStyles.faint}>OHLC · VOL · MA50 · MA200 · click compare ▸</Mono>
          </Box>
          <Box label="◢ SCORE · BREAKDOWN" style={{ padding: 8 }}>
            {[
              ['수익성', 41, 25, wfStyles.amber], ['안정성', 88, 25, wfStyles.green],
              ['성장성', 24, 20, wfStyles.red], ['밸류', 0, 20, wfStyles.red],
              ['리스크', 78, 10, wfStyles.green],
            ].map(([l, p, w, c], i) => (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '50px 1fr 22px 22px', gap: 4, alignItems: 'center', padding: '2px 0' }}>
                <Mono size={9}>{l}</Mono>
                <Bar pct={p} color={c} w={180} />
                <Mono size={9} weight={700} color={c}>{p}</Mono>
                <Mono size={7} color={wfStyles.faint}>{w}%</Mono>
              </div>
            ))}
          </Box>
          <Box label="◢ METRICS" style={{ padding: 6 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 4 }}>
              {[
                ['PER', '72.6x', wfStyles.amber], ['PBR', '9.8x', wfStyles.amber],
                ['ROE', '12.1%', wfStyles.green], ['OPM', '7.4%', wfStyles.amber],
                ['DEBT', '17%', wfStyles.green], ['REV g', '+8.7%', wfStyles.green],
                ['EPS g', '-22.4%', wfStyles.red], ['CR', '173%', wfStyles.green],
                ['FCFM', '4.8%', wfStyles.amber],
              ].map(([l, v, c], i) => (
                <div key={i} style={{ borderLeft: `2px solid ${c}`, padding: '1px 6px' }}>
                  <Mono size={7} color={wfStyles.faint}>{l}</Mono>
                  <Mono size={11} weight={700} color={c}>{v}</Mono>
                </div>
              ))}
            </div>
          </Box>
        </div>

        {/* Right: pitch + peers + history collapsed */}
        <div style={{ display: 'grid', gridTemplateRows: '1.4fr 1fr 0.8fr', gap: pad, minHeight: 0 }}>
          <Box label="◢ PITCH" style={{ padding: 8, overflow: 'hidden' }}>
            <Mono size={8} color={wfStyles.faint}>KEY Q</Mono>
            <Mono size={10} style={{ display: 'block', lineHeight: 1.3 }}>FSD와 ESS가 자동차 마진 둔화를 상쇄할 수 있는가?</Mono>
            <Mono size={8} color={wfStyles.green} style={{ marginTop: 6 }}>+ THESIS</Mono>
            <Squiggle width={260} /><Squiggle width={240} /><Squiggle width={250} />
            <Mono size={8} color={wfStyles.green} style={{ marginTop: 4 }}>+ CATALYST</Mono>
            <Squiggle width={250} /><Squiggle width={220} />
            <Mono size={8} color={wfStyles.red} style={{ marginTop: 4 }}>− RISK</Mono>
            <Squiggle width={240} /><Squiggle width={210} />
            <Mono size={8} color={wfStyles.cyan} style={{ marginTop: 4 }}>~ VARIANT</Mono>
            <Squiggle width={220} />
          </Box>
          <Box label="◢ PEER" style={{ padding: 6 }}>
            <Mono size={7} color={wfStyles.faint} style={{ display: 'block' }}>{'  '.padEnd(8)} PER  PBR  ROE   D/E</Mono>
            {[
              ['TSLA', 72.6, 9.8, 12.1, 17, true],
              ['AAPL', 29.4, 36.2, 156, 145, false],
              ['005930', 18.4, 1.3, 7.6, 27, false],
              ['NVDA', 65.2, 24.1, 91, 12, false],
              ['7203', 9.2, 1.0, 10.9, 95, false],
            ].map(([t, per, pbr, roe, de, a], i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '60px repeat(4, 1fr)',
                gap: 2, padding: '2px 4px', background: a ? wfStyles.amber + '22' : 'transparent',
              }}>
                <Mono size={9} weight={a ? 700 : 400}>{t}</Mono>
                <Mono size={9} color={wfStyles.ink}>{per}</Mono>
                <Mono size={9} color={wfStyles.ink}>{pbr}</Mono>
                <Mono size={9} color={wfStyles.ink}>{roe}</Mono>
                <Mono size={9} color={wfStyles.ink}>{de}</Mono>
              </div>
            ))}
          </Box>
          <Box label="◢ HX · 12M" style={{ padding: 6 }}>
            <Sparkline width={240} height={36} accent={wfStyles.amber} />
            <Mono size={8} color={wfStyles.faint}>52 → 48 → 50 → 47 → 44 (12 snapshots)</Mono>
            <Mono size={8} color={wfStyles.cyan} style={{ display: 'block', marginTop: 2 }}>+ snapshot today</Mono>
          </Box>
        </div>
      </div>

      <Annotation style={{ position: 'absolute', top: 50, left: 1080, width: 200, transform: 'rotate(-2deg)' }}>
        F1-F5 + ":" 명령어로 패널 점프
      </Annotation>
      <Annotation side="left" style={{ position: 'absolute', top: 130, left: 270, width: 220, transform: 'rotate(1deg)' }} color={wfStyles.cyan}>
        헤더 1줄에 의사결정 6개 변수 압축
      </Annotation>
      <Annotation style={{ position: 'absolute', top: 660, left: 1080, width: 180, transform: 'rotate(2deg)' }} color={wfStyles.amber}>
        ◢ = 접기/펼치기. 모든 게 한 화면에
      </Annotation>
    </div>
  );
};

// ──────────────────────────────────────────────────────────
// App with Tweaks
// ──────────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "density": "balanced",
  "showAnnotations": true
}/*EDITMODE-END*/;

const App = () => {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  return (
    <>
      <DesignCanvas>
        <DCSection id="intro" title="시작점 · 의도" subtitle="현재 사이트의 9개 패널을 Bloomberg Terminal 톤으로 재구성하는 4가지 방향">
          <DCArtboard id="readme" label="콘셉트 · 읽고 시작" width={760} height={520}>
            <div style={{ background: wfStyles.paper, padding: 36, height: '100%', fontFamily: wfStyles.mono, color: wfStyles.ink, boxSizing: 'border-box' }}>
              <Mono size={11} color={wfStyles.amber} weight={700}>▮ THESIS//TRACK · WIREFRAME ROUND 1</Mono>
              <Hand size={32} style={{ display: 'block', marginTop: 16, lineHeight: 1.1 }}>
                "Stock Pitch 사이트를<br/>Bloomberg Terminal처럼"
              </Hand>
              <div style={{ height: 1, background: wfStyles.pencil, opacity: 0.3, margin: '20px 0' }}/>
              <Mono size={11} style={{ lineHeight: 1.7, display: 'block' }}>
                현재 사이트는 사이드바(검정 그린) + 9개 패널이 한 화면에 펼쳐진 구조입니다.<br/>
                정보 밀도는 충분하지만, <span style={{ color: wfStyles.amber }}>의사결정 흐름</span>이 잘 안 보이고 시각적으로 분산됩니다.
              </Mono>
              <Mono size={11} style={{ lineHeight: 1.7, display: 'block', marginTop: 10 }}>
                Bloomberg Terminal의 핵심 요소를 빌립니다 —<br/>
                • <span style={{ color: wfStyles.amber }}>Amber/Cyan 액센트</span> · 검은 배경 · 모노스페이스<br/>
                • <span style={{ color: wfStyles.amber }}>Command bar</span> · 키보드 우선 네비게이션<br/>
                • <span style={{ color: wfStyles.amber }}>Ticker rail</span> · 시장 맥락은 항상 위에<br/>
                • <span style={{ color: wfStyles.amber }}>한 줄에 핵심 변수</span> 압축 (price · target · upside · score · review)
              </Mono>
              <Mono size={11} style={{ lineHeight: 1.7, display: 'block', marginTop: 16, color: wfStyles.faint }}>
                아래 4개 와이어프레임은 같은 데이터를 4가지 다른 구조로 배치한 것입니다.<br/>
                탭/마스터-디테일/4분할/단일 dense 페이지 — 어느 흐름이 가장 자연스러운지 골라주세요.
              </Mono>
              <Hand size={14} color={wfStyles.cyan} style={{ display: 'block', marginTop: 20 }}>
                ↓ 우측 Tweaks에서 정보 밀도 조절 가능
              </Hand>
            </div>
          </DCArtboard>
        </DCSection>

        <DCSection id="v1" title="V1 · Classic 4-Quadrant" subtitle="모든 정보가 한 화면에 — 좌측 watchlist, 중앙 chart+score, 우측 pitch 고정">
          <DCArtboard id="v1-main" label="V1 · 4-Quadrant Dense" width={1280} height={800}>
            <V1 density={t.density} />
          </DCArtboard>
        </DCSection>

        <DCSection id="v2" title="V2 · Tabbed Workspace" subtitle="9개 패널을 5-6개 탭으로 그룹화 — 의사결정 헤더는 항상 고정">
          <DCArtboard id="v2-main" label="V2 · Tabbed (Overview/Pitch/Val/Peer/Hx/Notes)" width={1280} height={800}>
            <V2 density={t.density} />
          </DCArtboard>
        </DCSection>

        <DCSection id="v3" title="V3 · Master-Detail" subtitle="좌측 영구 요약 카드 + 우측 한 패널만 깊게 — 분석 모드">
          <DCArtboard id="v3-main" label="V3 · Master-Detail (Pitch focused)" width={1280} height={800}>
            <V3 density={t.density} />
          </DCArtboard>
        </DCSection>

        <DCSection id="v4" title="V4 · Command-Driven Max Density" subtitle="키보드 명령 + 단일 페이지 collapsible · 가장 Bloomberg스러운 극단">
          <DCArtboard id="v4-main" label="V4 · Command-Driven (F1-F5 + ':' cmd)" width={1280} height={800}>
            <V4 density={t.density} />
          </DCArtboard>
        </DCSection>

        <DCSection id="next" title="다음 단계" subtitle="고른 방향을 hi-fi로 발전">
          <DCArtboard id="next-card" label="다음에 할 일" width={760} height={400}>
            <div style={{ background: wfStyles.paper, padding: 36, height: '100%', fontFamily: wfStyles.mono, color: wfStyles.ink, boxSizing: 'border-box' }}>
              <Mono size={11} color={wfStyles.amber} weight={700}>▮ NEXT</Mono>
              <Hand size={26} style={{ display: 'block', marginTop: 12 }}>골라주시면 hi-fi로 발전</Hand>
              <div style={{ marginTop: 18, lineHeight: 1.9 }}>
                <Mono size={12} style={{ display: 'block' }}>1. 어느 구조 (V1/V2/V3/V4 또는 하이브리드)</Mono>
                <Mono size={12} style={{ display: 'block' }}>2. 검정 배경 vs 따뜻한 페이퍼 배경</Mono>
                <Mono size={12} style={{ display: 'block' }}>3. 사이드바 디자인 변형 추가 탐색 여부</Mono>
                <Mono size={12} style={{ display: 'block' }}>4. 한 패널 (예: Pitch)을 깊게 디자인할지</Mono>
              </div>
              <Hand size={14} color={wfStyles.cyan} style={{ display: 'block', marginTop: 24 }}>
                "V2 + V4 헤더로 가자" 처럼 자유롭게 섞어주셔도 됩니다 ✓
              </Hand>
            </div>
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks">
        <TweakSection title="View">
          <TweakRadio
            label="정보 밀도"
            value={t.density}
            onChange={(v) => setTweak('density', v)}
            options={[
              { value: 'tight', label: 'Tight' },
              { value: 'balanced', label: 'Balanced' },
              { value: 'loose', label: 'Loose' },
            ]}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
