/* global React, ReactDOM, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakSlider, TweakToggle, TweakColor */
/* global T, Cell, Stat, ScoreRing, ScoreBar, Spark, PriceChart, CommandBar, TickerRail, HeroStrip, PitchHeadline */
/* global fmtNum, fmtPx, sign, colorForChange, TSLA, AAPL, NVDA, SAMSUNG, STOCKS, PEERS, WATCHLIST, MARKET_TICKERS */
const { useState, useEffect, useMemo, useRef, useCallback } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "density": "balanced",
  "accent": "#FF9500",
  "showTickerRail": true
} /*EDITMODE-END*/;

// ──────────────────────────────────────────────────────────
// Watchlist (left rail)
// ──────────────────────────────────────────────────────────
const Watchlist = ({ active, setActive }) => {
  return (
    <Cell label={`Watchlist · ${WATCHLIST.length}`} accent={T.amber}>
      <div style={{
        display: 'grid', gridTemplateColumns: '14px 1fr auto auto',
        gap: 10, padding: '6px 10px',
        fontSize: 9, color: T.inkFaint, letterSpacing: '0.1em',
        borderBottom: `1px solid ${T.borderSoft}`, textTransform: 'uppercase'
      }}>
        <span /><span>Symbol</span><span style={{ textAlign: 'right' }}>Score</span><span style={{ textAlign: 'right' }}>Δ%</span>
      </div>
      <div>
        {WATCHLIST.map((w) => {
          const isActive = w.symbol === active;
          return (
            <button key={w.symbol}
            onClick={() => setActive(w.symbol)}
            style={{
              display: 'grid', gridTemplateColumns: '14px 1fr auto auto',
              gap: 10, padding: '8px 10px',
              width: '100%', alignItems: 'center',
              background: isActive ? `${T.amber}14` : 'transparent',
              border: 0, borderLeft: `2px solid ${isActive ? T.amber : 'transparent'}`,
              borderBottom: `1px solid ${T.borderSoft}`,
              color: T.ink, fontFamily: T.font, cursor: 'pointer',
              textAlign: 'left',
              transition: 'background 0.12s'
            }}
            onMouseEnter={(e) => {if (!isActive) e.currentTarget.style.background = T.surface2;}}
            onMouseLeave={(e) => {if (!isActive) e.currentTarget.style.background = 'transparent';}}>
              
              <span style={{ fontSize: 12 }}>{w.flag}</span>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 11.5, fontWeight: 700, color: isActive ? T.amber : T.ink, letterSpacing: '0.02em' }}>
                  {w.symbol}
                </div>
                <div style={{ fontSize: 9.5, color: T.inkFaint, marginTop: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {w.name}
                </div>
              </div>
              <div style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                <div style={{
                  fontSize: 11.5, fontWeight: 700,
                  color: w.score >= 70 ? T.green : w.score >= 50 ? T.amber : T.red
                }}>
                  {w.score}
                </div>
                <div style={{ fontSize: 9, color: T.inkFaint, marginTop: 1 }}>
                  {fmtPx(w.price, w.currency)}
                </div>
              </div>
              <div style={{
                textAlign: 'right', fontSize: 10.5, fontWeight: 600,
                color: colorForChange(w.change), fontVariantNumeric: 'tabular-nums'
              }}>
                {sign(w.change)}{w.change.toFixed(2)}
              </div>
            </button>);

        })}
      </div>
    </Cell>);

};

// ──────────────────────────────────────────────────────────
// Score breakdown (5 dimensions)
// ──────────────────────────────────────────────────────────
const ScoreBreakdown = ({ scores }) => {
  const dims = [
  { key: 'profitability', label: '수익성 · Profitability', val: scores.profitability, w: scores.weights.profitability },
  { key: 'stability', label: '안정성 · Stability', val: scores.stability, w: scores.weights.stability },
  { key: 'growth', label: '성장성 · Growth', val: scores.growth, w: scores.weights.growth },
  { key: 'valuation', label: '가치 · Valuation', val: scores.valuation, w: scores.weights.valuation },
  { key: 'risk', label: '리스크 · Risk', val: scores.risk, w: scores.weights.risk }];

  const colorFor = (v) => v >= 70 ? T.green : v >= 50 ? T.amber : v >= 30 ? T.yellow : T.red;
  return (
    <Cell label="Score Composition · 5D" accent={T.cyan}>
      <div style={{ padding: '12px 14px' }}>
        {dims.map((d, i) =>
        <div key={d.key} style={{ marginBottom: i === dims.length - 1 ? 0 : 10 }}>
            <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
            marginBottom: 4, fontVariantNumeric: 'tabular-nums'
          }}>
              <span style={{ fontSize: 10.5, color: T.inkDim, letterSpacing: '0.02em' }}>
                {d.label}
                <span style={{ color: T.inkFaint, marginLeft: 8 }}>w={d.w}%</span>
              </span>
              <span style={{ fontSize: 12, fontWeight: 700, color: colorFor(d.val) }}>
                {d.val}
              </span>
            </div>
            <ScoreBar pct={d.val} color={colorFor(d.val)} height={4} />
          </div>
        )}
      </div>
    </Cell>);

};

// ──────────────────────────────────────────────────────────
// Metrics grid
// ──────────────────────────────────────────────────────────
const MetricsGrid = ({ metrics }) => {
  const items = [
  { label: 'PER', v: `${metrics.per.toFixed(1)}x`, ok: metrics.per < 30 },
  { label: 'PBR', v: `${metrics.pbr.toFixed(1)}x`, ok: metrics.pbr < 5 },
  { label: 'ROE', v: `${metrics.roe.toFixed(1)}%`, ok: metrics.roe > 10 },
  { label: 'OP MARGIN', v: `${metrics.opMargin.toFixed(1)}%`, ok: metrics.opMargin > 10 },
  { label: 'DEBT/EQ', v: `${metrics.debtRatio}%`, ok: metrics.debtRatio < 100 },
  { label: 'REV GR', v: `${sign(metrics.revGrowth)}${metrics.revGrowth.toFixed(1)}%`, ok: metrics.revGrowth > 5 },
  { label: 'EPS GR', v: `${sign(metrics.epsGrowth)}${metrics.epsGrowth.toFixed(1)}%`, ok: metrics.epsGrowth > 0 },
  { label: 'FCF MGN', v: `${metrics.fcfMargin.toFixed(1)}%`, ok: metrics.fcfMargin > 5 }];

  return (
    <Cell label="Fundamentals · FY2025" accent={T.amber}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 1, background: T.borderSoft }}>
        {items.map((m, i) =>
        <div key={i} style={{ padding: '10px 12px', background: T.surface }}>
            <div style={{ fontSize: 9, color: T.inkFaint, letterSpacing: '0.12em', marginBottom: 4 }}>
              {m.label}
            </div>
            <div style={{
            fontSize: 14, fontWeight: 700, color: m.ok ? T.ink : T.red,
            fontVariantNumeric: 'tabular-nums', display: 'flex', alignItems: 'center', gap: 6
          }}>
              {m.v}
              <span style={{
              width: 5, height: 5, borderRadius: '50%',
              background: m.ok ? T.green : T.red,
              boxShadow: `0 0 4px ${m.ok ? T.green : T.red}`
            }} />
            </div>
          </div>
        )}
      </div>
    </Cell>);

};

// ──────────────────────────────────────────────────────────
// Chart with header
// ──────────────────────────────────────────────────────────
const ChartPanel = ({ stock, accent }) => {
  const [tf, setTf] = useState('6M');
  return (
    <Cell label={`${stock.symbol} · Price History`} accent={T.cyan}>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '8px 14px', borderBottom: `1px solid ${T.borderSoft}`
      }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'baseline', fontVariantNumeric: 'tabular-nums' }}>
          <span style={{ fontSize: 18, fontWeight: 700, color: T.ink }}>${fmtPx(stock.price, stock.currency)}</span>
          <span style={{ fontSize: 11, color: T.green }}>+{(stock.price - stock.prevClose).toFixed(2)} (+1.21%)</span>
          <span style={{ fontSize: 10, color: T.inkFaint, marginLeft: 8 }}>· vs target $280 → +10.5%</span>
        </div>
        <div style={{ display: 'flex', gap: 0, border: `1px solid ${T.border}` }}>
          {['1D', '1W', '1M', '6M', '1Y', '5Y'].map((t) =>
          <button key={t} onClick={() => setTf(t)}
          style={{
            padding: '4px 10px', fontSize: 10, fontFamily: T.font,
            background: tf === t ? T.amber : 'transparent',
            color: tf === t ? '#000' : T.inkDim,
            border: 0, borderRight: t !== '5Y' ? `1px solid ${T.border}` : 0,
            cursor: 'pointer', fontWeight: tf === t ? 700 : 500
          }}>{t}</button>
          )}
        </div>
      </div>
      <div style={{ padding: '8px 4px 4px 4px' }}>
        <PriceChart data={stock.priceHistory} height={210} accent={accent} />
      </div>
    </Cell>);

};

// ──────────────────────────────────────────────────────────
// Pitch panel (full thesis)
// ──────────────────────────────────────────────────────────
const PitchPanel = ({ stock }) =>
<Cell label="Investment Thesis" accent={T.amber}>
    <div style={{ padding: '12px 14px' }}>
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 9, color: T.inkFaint, letterSpacing: '0.14em', marginBottom: 6 }}>KEY QUESTION</div>
        <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: T.ink, lineHeight: 1.5, fontStyle: 'italic' }}>
          {stock.keyQuestion}
        </div>
      </div>
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 9, color: T.inkFaint, letterSpacing: '0.14em', marginBottom: 6 }}>THESIS · 3-PT</div>
        {stock.thesis.map((t, i) =>
      <div key={i} style={{ display: 'flex', gap: 8, fontSize: 11.5, color: T.ink, lineHeight: 1.5, marginBottom: 6 }}>
            <span style={{ color: T.amber, fontWeight: 700, flex: '0 0 auto' }}>0{i + 1}</span>
            <span style={{ fontFamily: "'Inter', sans-serif" }}>{t}</span>
          </div>
      )}
      </div>
      <div style={{
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1,
      background: T.borderSoft, marginBottom: 12
    }}>
        <div style={{ padding: '10px 12px', background: T.surface }}>
          <div style={{ fontSize: 9, color: T.green, letterSpacing: '0.14em', marginBottom: 6 }}>↗ CATALYSTS</div>
          {stock.catalysts.map((c, i) =>
        <div key={i} style={{ fontSize: 10.5, color: T.inkDim, marginBottom: 3, fontFamily: "'Inter', sans-serif" }}>
              · {c}
            </div>
        )}
        </div>
        <div style={{ padding: '10px 12px', background: T.surface }}>
          <div style={{ fontSize: 9, color: T.red, letterSpacing: '0.14em', marginBottom: 6 }}>↘ RISKS</div>
          {stock.risks.map((r, i) =>
        <div key={i} style={{ fontSize: 10.5, color: T.inkDim, marginBottom: 3, fontFamily: "'Inter', sans-serif" }}>
              · {r}
            </div>
        )}
        </div>
      </div>
      <div style={{
      padding: '10px 12px', background: T.surface2,
      borderLeft: `2px solid ${T.cyan}`
    }}>
        <div style={{ fontSize: 9, color: T.cyan, letterSpacing: '0.14em', marginBottom: 4 }}>VARIANT VIEW</div>
        <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: T.ink, lineHeight: 1.55 }}>
          {stock.variantView}
        </div>
      </div>
    </div>
  </Cell>;


// ──────────────────────────────────────────────────────────
// Valuation scenarios
// ──────────────────────────────────────────────────────────
const ValuationPanel = ({ stock }) => {
  const v = stock.valuation;
  const max = Math.max(v.bull.price, v.base.price, v.bear.price);
  const rows = [
  { tag: 'BULL', color: T.green, ...v.bull, upside: (v.bull.price - stock.price) / stock.price * 100 },
  { tag: 'BASE', color: T.amber, ...v.base, upside: (v.base.price - stock.price) / stock.price * 100 },
  { tag: 'BEAR', color: T.red, ...v.bear, upside: (v.bear.price - stock.price) / stock.price * 100 }];

  return (
    <Cell label="Valuation Scenarios" accent={T.cyan}>
      <div style={{ padding: '10px 14px' }}>
        {rows.map((r) =>
        <div key={r.tag} style={{ marginBottom: 10 }}>
            <div style={{
            display: 'grid', gridTemplateColumns: 'auto 1fr auto auto',
            gap: 12, alignItems: 'baseline', marginBottom: 4, fontVariantNumeric: 'tabular-nums'
          }}>
              <span style={{
              fontSize: 9.5, fontWeight: 700, color: r.color, letterSpacing: '0.14em',
              padding: '2px 6px', border: `1px solid ${r.color}`, lineHeight: 1
            }}>{r.tag}</span>
              <span style={{ fontSize: 10, color: T.inkFaint }}>
                EPS ${r.driver} × PER {r.multiple}x · MoS {r.mos}%
              </span>
              <span style={{ fontSize: 14, fontWeight: 700, color: r.color }}>
                ${fmtPx(r.price, stock.currency)}
              </span>
              <span style={{ fontSize: 10, color: colorForChange(r.upside), minWidth: 56, textAlign: 'right' }}>
                {sign(r.upside)}{r.upside.toFixed(1)}%
              </span>
            </div>
            <ScoreBar pct={r.price / max * 100} color={r.color} height={3} />
          </div>
        )}
        <div style={{
          marginTop: 10, padding: '8px 10px', background: T.surface2,
          fontSize: 10, color: T.inkDim, fontFamily: "'Inter', sans-serif", lineHeight: 1.5
        }}>
          <span style={{ color: T.amber, fontWeight: 700 }}>NOTE:</span> {v.note}
        </div>
      </div>
    </Cell>);

};

// ──────────────────────────────────────────────────────────
// Peer comparison
// ──────────────────────────────────────────────────────────
const PeerPanel = ({ peers }) =>
<Cell label="Peer Comparison" accent={T.cyan}>
    <div style={{ overflow: 'auto' }}>
      <table style={{
      width: '100%', borderCollapse: 'collapse', fontFamily: T.font,
      fontVariantNumeric: 'tabular-nums', fontSize: 10.5
    }}>
        <thead>
          <tr style={{ background: T.surface2 }}>
            {['Symbol', 'PER', 'PBR', 'ROE', 'D/E', 'Score'].map((h, i) =>
          <th key={h} style={{
            padding: '6px 10px',
            textAlign: i === 0 ? 'left' : 'right',
            fontSize: 9, color: T.inkFaint, fontWeight: 600,
            letterSpacing: '0.12em', textTransform: 'uppercase',
            borderBottom: `1px solid ${T.border}`
          }}>{h}</th>
          )}
          </tr>
        </thead>
        <tbody>
          {peers.map((p) =>
        <tr key={p.symbol} style={{
          background: p.active ? `${T.amber}10` : 'transparent',
          borderBottom: `1px solid ${T.borderSoft}`
        }}>
              <td style={{ padding: '8px 10px', borderLeft: `2px solid ${p.active ? T.amber : 'transparent'}` }}>
                <div style={{ fontWeight: 700, color: p.active ? T.amber : T.ink, fontSize: 11 }}>{p.symbol}</div>
                <div style={{ fontSize: 9, color: T.inkFaint, marginTop: 1 }}>{p.name}</div>
              </td>
              <td style={{ padding: '8px 10px', textAlign: 'right', color: T.ink, fontSize: "12px" }}>{p.per.toFixed(1)}x</td>
              <td style={{ padding: '8px 10px', textAlign: 'right', color: T.ink, fontSize: "12px" }}>{p.pbr.toFixed(1)}x</td>
              <td style={{ padding: '8px 10px', textAlign: 'right', color: T.ink, fontSize: "12px" }}>{p.roe.toFixed(1)}%</td>
              <td style={{ padding: '8px 10px', textAlign: 'right', color: T.ink, fontSize: "12px" }}>{p.debt}%</td>
              <td style={{ padding: '8px 10px', textAlign: 'right' }}>
                <span style={{
              display: 'inline-block', padding: '2px 8px', minWidth: 36,
              background: p.score >= 70 ? `${T.green}22` : p.score >= 50 ? `${T.amber}22` : `${T.red}22`,
              color: p.score >= 70 ? T.green : p.score >= 50 ? T.amber : T.red,
              fontWeight: 700, fontSize: "12px"
            }}>{p.score}</span>
              </td>
            </tr>
        )}
        </tbody>
      </table>
    </div>
  </Cell>;


// ──────────────────────────────────────────────────────────
// History / notes
// ──────────────────────────────────────────────────────────
const HistoryPanel = ({ notes }) =>
<Cell label="Decision Log · Notes" accent={T.amber}>
    <div style={{ padding: '4px 0' }}>
      {notes.map((n, i) =>
    <div key={i} style={{
      padding: '10px 14px',
      borderBottom: i === notes.length - 1 ? 0 : `1px solid ${T.borderSoft}`
    }}>
          <div style={{
        display: 'flex', alignItems: 'baseline', gap: 10,
        marginBottom: 4, fontVariantNumeric: 'tabular-nums'
      }}>
            <span style={{ fontSize: 10.5, color: T.amber, fontWeight: 700, letterSpacing: '0.02em' }}>
              {n.date}
            </span>
            <span style={{
          fontSize: 9, padding: '1px 6px', border: `1px solid ${T.border}`,
          color: T.inkDim, letterSpacing: '0.1em'
        }}>{n.kind.toUpperCase()}</span>
            {n.source &&
        <span style={{ fontSize: 9, color: T.cyan, marginLeft: 'auto' }}>↗ source</span>
        }
          </div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11.5, color: T.ink, lineHeight: 1.5 }}>
            {n.text}
          </div>
        </div>
    )}
    </div>
  </Cell>;


// ──────────────────────────────────────────────────────────
// Quality / data integrity
// ──────────────────────────────────────────────────────────
const QualityPanel = ({ stock }) => {
  const colorFor = (k) => k === 'ok' ? T.green : k === 'warn' ? T.yellow : T.cyan;
  const symFor = (k) => k === 'ok' ? '✓' : k === 'warn' ? '!' : 'i';
  return (
    <Cell label="Data Quality · Watch" accent={T.cyan}>
      <div style={{ padding: '6px 0' }}>
        {stock.quality.map((q, i) =>
        <div key={i} style={{
          display: 'flex', gap: 10, padding: '6px 12px', alignItems: 'flex-start',
          borderBottom: i === stock.quality.length - 1 ? 0 : `1px solid ${T.borderSoft}`
        }}>
            <span style={{
            flex: '0 0 auto',
            width: 14, height: 14, display: 'grid', placeItems: 'center',
            background: `${colorFor(q.kind)}22`,
            color: colorFor(q.kind),
            fontSize: 9, fontWeight: 800, marginTop: 1
          }}>{symFor(q.kind)}</span>
            <span style={{ fontSize: 10.5, color: T.inkDim, lineHeight: 1.45, fontFamily: "'Inter', sans-serif" }}>
              {q.text}
            </span>
          </div>
        )}
      </div>
    </Cell>);

};

// ──────────────────────────────────────────────────────────
// Status bar (bottom)
// ──────────────────────────────────────────────────────────
const StatusBar = ({ stock }) =>
<div style={{
  height: 24, padding: '0 14px',
  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
  background: T.surface, borderTop: `1px solid ${T.border}`,
  fontSize: 10, color: T.inkFaint, letterSpacing: '0.06em'
}}>
    <div style={{ display: 'flex', gap: 14 }}>
      <span><span style={{ color: T.green }}>●</span> CONNECTED</span>
      <span style={{ color: T.borderSoft }}>│</span>
      <span>SRC <span style={{ color: T.inkDim }}>{stock.source}</span></span>
      <span style={{ color: T.borderSoft }}>│</span>
      <span>FY <span style={{ color: T.inkDim }}>{stock.asOf}</span></span>
      <span style={{ color: T.borderSoft }}>│</span>
      <span>CACHE <span style={{ color: T.inkDim }}>2m AGO</span></span>
    </div>
    <div style={{ display: 'flex', gap: 14 }}>
      <span>MEM 142MB</span>
      <span style={{ color: T.borderSoft }}>│</span>
      <span>ALERTS <span style={{ color: T.amber }}>2</span></span>
      <span style={{ color: T.borderSoft }}>│</span>
      <span>USER <span style={{ color: T.inkDim }}>analyst@thesistrack</span></span>
    </div>
  </div>;


// ──────────────────────────────────────────────────────────
// Command palette overlay (`:` to open)
// ──────────────────────────────────────────────────────────
const PALETTE_CMDS = [
{ cmd: ':open', args: '<symbol>', desc: '종목 열기 (TSLA, AAPL, NVDA, 005930)' },
{ cmd: ':review', args: '<symbol>', desc: '리뷰 시작 — thesis 재확인' },
{ cmd: ':compare', args: '<a> <b>', desc: '두 종목 나란히 비교' },
{ cmd: ':alert', args: '<sym> <px>', desc: '가격 도달 알림 설정' },
{ cmd: ':export', args: 'pptx|pdf', desc: '현재 뷰 내보내기' },
{ cmd: ':theme', args: 'amber|cyan', desc: 'Accent 컬러 변경' }];


const CommandPalette = ({ open, onClose, onRun }) => {
  const [q, setQ] = useState('');
  const inputRef = useRef(null);
  useEffect(() => {if (open) {setQ(':');setTimeout(() => inputRef.current?.focus(), 0);}}, [open]);

  const filtered = useMemo(() => {
    const needle = q.replace(/^:/, '').trim().toLowerCase();
    if (!needle) return PALETTE_CMDS;
    return PALETTE_CMDS.filter((c) => c.cmd.includes(needle) || c.desc.toLowerCase().includes(needle));
  }, [q]);

  if (!open) return null;
  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.65)',
      backdropFilter: 'blur(2px)', zIndex: 100,
      display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
      paddingTop: '14vh'
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{
        width: 580, maxWidth: '90vw',
        background: T.surface, border: `1px solid ${T.amber}`,
        boxShadow: `0 0 40px ${T.amber}33, 0 20px 60px rgba(0,0,0,0.6)`,
        fontFamily: T.font
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '12px 16px', borderBottom: `1px solid ${T.border}`
        }}>
          <span style={{ color: T.amber, fontSize: 16, fontWeight: 700 }}>&gt;</span>
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape') onClose();
              if (e.key === 'Enter') {onRun(q);onClose();}
            }}
            placeholder=":open TSLA"
            style={{
              flex: 1, background: 'transparent', border: 0, outline: 0,
              color: T.amber, fontFamily: T.font, fontSize: 15, fontWeight: 600
            }} />
          
          <span style={{ fontSize: 10, color: T.inkFaint }}>
            <kbd style={kbdInline}>↵</kbd> run · <kbd style={kbdInline}>esc</kbd> close
          </span>
        </div>
        <div style={{ maxHeight: 320, overflow: 'auto' }}>
          {filtered.map((c, i) =>
          <div key={c.cmd} style={{
            display: 'grid', gridTemplateColumns: '120px 1fr',
            gap: 14, padding: '10px 16px',
            borderBottom: i === filtered.length - 1 ? 0 : `1px solid ${T.borderSoft}`,
            cursor: 'pointer', alignItems: 'baseline'
          }}
          onClick={() => {onRun(c.cmd + (c.args ? ' ' : ''));if (!c.args) onClose();else inputRef.current?.focus();setQ(c.cmd + ' ');}}
          onMouseEnter={(e) => e.currentTarget.style.background = T.surface2}
          onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
              <div>
                <span style={{ color: T.amber, fontWeight: 700, fontSize: 12 }}>{c.cmd}</span>
                {c.args && <span style={{ color: T.inkFaint, fontSize: 10.5, marginLeft: 6 }}>{c.args}</span>}
              </div>
              <div style={{ fontSize: 11, color: T.inkDim, fontFamily: "'Inter', sans-serif" }}>
                {c.desc}
              </div>
            </div>
          )}
          {filtered.length === 0 &&
          <div style={{ padding: '20px 16px', fontSize: 11, color: T.inkFaint, textAlign: 'center' }}>
              No matching command.
            </div>
          }
        </div>
      </div>
    </div>);

};

const kbdInline = {
  display: 'inline-block', padding: '0px 4px', background: T.surface2,
  border: `1px solid ${T.border}`, borderRadius: 2,
  fontSize: 9.5, fontFamily: T.font, color: T.inkDim, margin: '0 1px'
};

// ──────────────────────────────────────────────────────────
// Pre-mortem · numbers to watch with status
// ──────────────────────────────────────────────────────────
const PRE_MORTEM_DATA = {
  TSLA: [
  { metric: '자동차 gross margin', current: 16.3, threshold: 18, target: '≥ 18%', status: 'warn', delta: -1.7 },
  { metric: '에너지 매출 성장률 (YoY)', current: 84, threshold: 60, target: '≥ 60%', status: 'ok', delta: 24 },
  { metric: 'FCF 마진', current: 4.8, threshold: 7, target: '≥ 7%', status: 'warn', delta: -2.2 },
  { metric: '인도량 성장률 (YoY)', current: 6.2, threshold: 10, target: '≥ 10%', status: 'breach', delta: -3.8 }],

  AAPL: [
  { metric: '서비스 매출 성장률', current: 14.1, threshold: 10, target: '≥ 10%', status: 'ok', delta: 4.1 },
  { metric: 'iPhone ASP', current: 989, threshold: 950, target: '≥ $950', status: 'ok', delta: 39 },
  { metric: '중국 매출 (YoY)', current: -8.2, threshold: 0, target: '≥ 0%', status: 'breach', delta: -8.2 },
  { metric: '자사주 매입 (TTM, $B)', current: 102, threshold: 90, target: '≥ $90B', status: 'ok', delta: 12 }],

  NVDA: [
  { metric: '데이터센터 매출 QoQ', current: 12.4, threshold: 5, target: '≥ 5%', status: 'ok', delta: 7.4 },
  { metric: '게임 매출 (YoY)', current: 18.0, threshold: 10, target: '≥ 10%', status: 'ok', delta: 8 },
  { metric: 'Capex 가이던스 (HS, $B)', current: 218, threshold: 180, target: '≥ $180B', status: 'ok', delta: 38 },
  { metric: '재고 일수', current: 92, threshold: 80, target: '≤ 80일', status: 'warn', delta: 12 }],

  '005930': [
  { metric: 'HBM 매출 (Q, ₩조)', current: 4.2, threshold: 5.5, target: '≥ 5.5조', status: 'warn', delta: -1.3 },
  { metric: '메모리 OP 마진', current: 28.4, threshold: 25, target: '≥ 25%', status: 'ok', delta: 3.4 },
  { metric: '파운드리 가동률', current: 64, threshold: 75, target: '≥ 75%', status: 'breach', delta: -11 },
  { metric: '재고 일수', current: 86, threshold: 100, target: '≤ 100일', status: 'ok', delta: -14 }]

};

const PreMortemPanel = ({ symbol, stock }) => {
  const items = PRE_MORTEM_DATA[symbol] || [];
  const colorFor = (s) => s === 'ok' ? T.green : s === 'warn' ? T.yellow : T.red;
  const symFor = (s) => s === 'ok' ? '✓' : s === 'warn' ? '!' : '✕';
  const breaches = items.filter((i) => i.status === 'breach').length;
  const warns = items.filter((i) => i.status === 'warn').length;
  return (
    <Cell label={`Pre-Mortem · ${symbol}`} accent={breaches > 0 ? T.red : warns > 0 ? T.yellow : T.green}>
      <div style={{
        display: 'grid', gridTemplateColumns: 'auto auto auto',
        gap: 1, background: T.borderSoft
      }}>
        <div style={{ padding: '8px 12px', background: T.surface }}>
          <div style={{ fontSize: 9, color: T.inkFaint, letterSpacing: '0.12em' }}>BREACH</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: breaches > 0 ? T.red : T.inkDim, fontVariantNumeric: 'tabular-nums' }}>
            {breaches}
          </div>
        </div>
        <div style={{ padding: '8px 12px', background: T.surface }}>
          <div style={{ fontSize: 9, color: T.inkFaint, letterSpacing: '0.12em' }}>WARN</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: warns > 0 ? T.yellow : T.inkDim, fontVariantNumeric: 'tabular-nums' }}>
            {warns}
          </div>
        </div>
        <div style={{ padding: '8px 12px', background: T.surface }}>
          <div style={{ fontSize: 9, color: T.inkFaint, letterSpacing: '0.12em' }}>TRIGGER</div>
          <div style={{ fontSize: 11, color: breaches > 0 ? T.red : T.inkDim, fontWeight: 600, lineHeight: 1.3, marginTop: 3 }}>
            {breaches > 0 ? '리뷰 필요' : '정상'}
          </div>
        </div>
      </div>
      <div>
        {items.map((it, i) =>
        <div key={i} style={{
          display: 'grid', gridTemplateColumns: '18px 1fr auto',
          gap: 10, padding: '9px 12px',
          borderTop: `1px solid ${T.borderSoft}`,
          alignItems: 'center'
        }}>
            <span style={{
            width: 16, height: 16, display: 'grid', placeItems: 'center',
            background: `${colorFor(it.status)}22`, color: colorFor(it.status),
            fontSize: 9, fontWeight: 800
          }}>{symFor(it.status)}</span>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 11, color: T.ink, fontFamily: "'Inter', sans-serif", marginBottom: 2 }}>
                {it.metric}
              </div>
              <div style={{ fontSize: 9.5, color: T.inkFaint, fontVariantNumeric: 'tabular-nums' }}>
                target <span style={{ color: T.inkDim }}>{it.target}</span>
              </div>
            </div>
            <div style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: colorFor(it.status) }}>
                {it.current}
              </div>
              <div style={{ fontSize: 9, color: colorForChange(it.delta), marginTop: 1 }}>
                {sign(it.delta)}{it.delta}
              </div>
            </div>
          </div>
        )}
      </div>
      <div style={{
        padding: '10px 12px', background: T.surface2,
        borderTop: `1px solid ${T.border}`
      }}>
        <div style={{ fontSize: 9, color: T.amber, letterSpacing: '0.14em', marginBottom: 4 }}>
          CHANGE-MIND CONDITION
        </div>
        <div style={{ fontSize: 10.5, color: T.inkDim, lineHeight: 1.5, fontFamily: "'Inter', sans-serif" }}>
          {stock.changeMind}
        </div>
      </div>
    </Cell>);

};

// ──────────────────────────────────────────────────────────
// Scenario simulator — PER × EPS sliders → live price
// ──────────────────────────────────────────────────────────
const ScenarioSim = ({ stock }) => {
  const base = stock.valuation.base;
  const [eps, setEps] = useState(base.driver);
  const [per, setPer] = useState(base.multiple);
  const [mos, setMos] = useState(0);
  useEffect(() => {setEps(base.driver);setPer(base.multiple);setMos(0);}, [stock.symbol]);

  const fairPrice = eps * per * (1 - mos / 100);
  const upside = (fairPrice - stock.price) / stock.price * 100;
  const verdict = upside > 20 ? { tag: 'BULL', color: T.green } :
  upside < -10 ? { tag: 'BEAR', color: T.red } :
  { tag: 'BASE', color: T.amber };

  const Slider = ({ label, value, min, max, step, onChange, fmt }) =>
  <div style={{ marginBottom: 14 }}>
      <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
      marginBottom: 4, fontVariantNumeric: 'tabular-nums'
    }}>
        <span style={{ fontSize: 10, color: T.inkFaint, letterSpacing: '0.1em' }}>{label}</span>
        <span style={{ fontSize: 12, fontWeight: 700, color: T.amber }}>{fmt(value)}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
    onChange={(e) => onChange(parseFloat(e.target.value))}
    style={{ width: '100%', accentColor: T.amber, height: 4 }} />
      <div style={{
      display: 'flex', justifyContent: 'space-between',
      fontSize: 9, color: T.inkFaint, fontVariantNumeric: 'tabular-nums', marginTop: 2
    }}>
        <span>{fmt(min)}</span><span>{fmt(max)}</span>
      </div>
    </div>;


  return (
    <Cell label="Scenario · What-If" accent={T.cyan}>
      <div style={{ padding: '14px 16px' }}>
        <Slider label="EPS Driver" value={eps} min={base.driver * 0.4} max={base.driver * 1.6} step={base.driver * 0.02}
        onChange={setEps} fmt={(v) => stock.currency === 'KRW' ? `₩${v.toFixed(0)}` : `$${v.toFixed(2)}`} />
        <Slider label="PER · Multiple" value={per} min={5} max={Math.max(80, base.multiple * 1.4)} step={1}
        onChange={setPer} fmt={(v) => `${v.toFixed(0)}x`} />
        <Slider label="Margin of Safety" value={mos} min={0} max={40} step={1}
        onChange={setMos} fmt={(v) => `${v}%`} />
        <div style={{
          marginTop: 4, padding: '12px 14px', background: T.bg,
          border: `1px solid ${verdict.color}`,
          boxShadow: `inset 0 0 12px ${verdict.color}22`,
          display: 'grid', gridTemplateColumns: 'auto 1fr auto', gap: 14, alignItems: 'center'
        }}>
          <span style={{
            padding: '3px 8px', border: `1px solid ${verdict.color}`,
            color: verdict.color, fontSize: 10, fontWeight: 700, letterSpacing: '0.14em'
          }}>{verdict.tag}</span>
          <div>
            <div style={{ fontSize: 9.5, color: T.inkFaint, letterSpacing: '0.1em' }}>FAIR VALUE</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: T.ink, fontVariantNumeric: 'tabular-nums' }}>
              {stock.currency === 'KRW' ? `₩${fmtPx(fairPrice, stock.currency)}` : `$${fmtPx(fairPrice, stock.currency)}`}
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 9.5, color: T.inkFaint, letterSpacing: '0.1em' }}>UPSIDE</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: colorForChange(upside), fontVariantNumeric: 'tabular-nums' }}>
              {sign(upside)}{upside.toFixed(1)}%
            </div>
          </div>
        </div>
      </div>
    </Cell>);

};

// ──────────────────────────────────────────────────────────
// Review queue · upcoming due dates
// ──────────────────────────────────────────────────────────
const ReviewQueue = ({ activeSymbol, setActive }) => {
  const queue = Object.values(STOCKS).map((s) => ({
    symbol: s.symbol, name: s.name, days: s.review.daysLeft, date: s.review.next, score: s.scores.overall, flag: s.flag
  })).sort((a, b) => a.days - b.days);

  return (
    <Cell label="Review Queue · Upcoming" accent={T.cyan}>
      {queue.map((q, i) => {
        const urgent = q.days <= 14;
        const isActive = q.symbol === activeSymbol;
        return (
          <button key={q.symbol}
          onClick={() => setActive(q.symbol)}
          style={{
            display: 'grid', gridTemplateColumns: '14px 1fr auto auto',
            gap: 10, padding: '9px 12px', width: '100%',
            alignItems: 'center', textAlign: 'left',
            background: isActive ? `${T.amber}10` : 'transparent',
            border: 0,
            borderTop: i === 0 ? 0 : `1px solid ${T.borderSoft}`,
            borderLeft: `2px solid ${isActive ? T.amber : 'transparent'}`,
            fontFamily: T.font, color: T.ink, cursor: 'pointer'
          }}>
            <span style={{ fontSize: 12 }}>{q.flag}</span>
            <div>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: isActive ? T.amber : T.ink }}>
                {q.symbol}
              </div>
              <div style={{ fontSize: 9.5, color: T.inkFaint, marginTop: 1 }}>{q.date}</div>
            </div>
            <div style={{
              padding: '2px 8px',
              background: urgent ? `${T.red}22` : `${T.cyan}22`,
              color: urgent ? T.red : T.cyan,
              fontSize: 11, fontWeight: 700, fontVariantNumeric: 'tabular-nums',
              letterSpacing: '0.04em'
            }}>D-{q.days}</div>
            <div style={{
              fontSize: 11, fontWeight: 700, fontVariantNumeric: 'tabular-nums',
              color: q.score >= 70 ? T.green : q.score >= 50 ? T.amber : T.red,
              minWidth: 24, textAlign: 'right'
            }}>{q.score}</div>
          </button>);

      })}
    </Cell>);

};

// ──────────────────────────────────────────────────────────
// Help overlay (`?` to open) — keyboard cheatsheet
// ──────────────────────────────────────────────────────────
const HELP_SHORTCUTS = [
{ group: 'Navigation', items: [
  { key: 'F1', desc: '개요 (Overview) — Hero / Pitch' },
  { key: 'F2', desc: 'Thesis 패널' },
  { key: 'F3', desc: 'Valuation 시나리오' },
  { key: 'F4', desc: 'Peer 비교' },
  { key: 'F5', desc: 'History · Decision Log' }]
},
{ group: 'Command', items: [
  { key: ':', desc: '커맨드 팔레트 열기' },
  { key: '/', desc: '검색 (예정)' },
  { key: '?', desc: '이 도움말 토글' },
  { key: 'Esc', desc: '오버레이 닫기' }]
},
{ group: 'Commands (`:` 입력)', items: [
  { key: ':open <sym>', desc: '종목 열기 — TSLA, AAPL, NVDA, 005930' },
  { key: ':review <sym>', desc: '리뷰 시작 — thesis 재확인' },
  { key: ':compare <a> <b>', desc: '두 종목 비교' },
  { key: ':alert <sym> <px>', desc: '가격 도달 알림' },
  { key: ':export pptx', desc: '리뷰 리포트 내보내기' },
  { key: ':theme amber|cyan|green|purple', desc: 'Accent 컬러' }]
}];


const HelpOverlay = ({ open, onClose }) => {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)',
      backdropFilter: 'blur(2px)', zIndex: 100,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 24
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{
        width: 720, maxWidth: '92vw', maxHeight: '86vh', overflow: 'auto',
        background: T.surface, border: `1px solid ${T.amber}`,
        boxShadow: `0 0 40px ${T.amber}33, 0 20px 60px rgba(0,0,0,0.6)`,
        fontFamily: T.font
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '14px 20px', borderBottom: `1px solid ${T.border}`,
          background: T.surface2
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ color: T.amber, fontWeight: 700, fontSize: 12, letterSpacing: '0.14em' }}>
              KEYBOARD · CHEATSHEET
            </span>
            <span style={{ fontSize: 10, color: T.inkFaint, letterSpacing: '0.1em' }}>
              press <kbd style={kbdInline}>?</kbd> anytime
            </span>
          </div>
          <button onClick={onClose} style={{
            background: 'transparent', border: `1px solid ${T.border}`,
            color: T.inkDim, padding: '4px 10px', fontSize: 10, fontFamily: T.font,
            cursor: 'pointer', letterSpacing: '0.1em'
          }}>ESC ✕</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1, background: T.borderSoft }}>
          {HELP_SHORTCUTS.map((g) =>
          <div key={g.group} style={{
            background: T.surface, padding: '14px 18px',
            gridColumn: g.group.startsWith('Commands') ? '1 / -1' : 'auto'
          }}>
              <div style={{
              fontSize: 9.5, color: T.cyan, letterSpacing: '0.16em',
              fontWeight: 700, marginBottom: 10
            }}>
                {g.group}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {g.items.map((it, i) =>
              <div key={i} style={{
                display: 'grid',
                gridTemplateColumns: g.group.startsWith('Commands') ? '220px 1fr' : '70px 1fr',
                gap: 12, alignItems: 'baseline'
              }}>
                    <div>
                      <kbd style={{
                    display: 'inline-block', padding: '3px 8px',
                    background: T.surface2, border: `1px solid ${T.border}`,
                    borderRadius: 2, fontSize: 11, fontFamily: T.font,
                    color: T.amber, fontWeight: 600
                  }}>{it.key}</kbd>
                    </div>
                    <div style={{ fontSize: 11, color: T.inkDim, lineHeight: 1.5, fontFamily: "'Inter', sans-serif" }}>
                      {it.desc}
                    </div>
                  </div>
              )}
              </div>
            </div>
          )}
        </div>
        <div style={{
          padding: '10px 20px', borderTop: `1px solid ${T.border}`,
          fontSize: 10, color: T.inkFaint, fontFamily: "'Inter', sans-serif",
          background: T.surface2
        }}>
          💡 단축키 옆 <kbd style={kbdInline}>?</kbd> 버튼은 항상 우측 하단에서 호출할 수 있습니다.
        </div>
      </div>
    </div>);

};

// Floating help button (always visible bottom-right hint)
const HelpFab = ({ onClick }) =>
<button onClick={onClick} title="도움말 (?)" style={{
  position: 'fixed', bottom: 36, right: 24, zIndex: 50,
  width: 32, height: 32, borderRadius: '50%',
  background: T.surface, border: `1px solid ${T.amber}`,
  color: T.amber, fontSize: 14, fontWeight: 700, fontFamily: T.font,
  cursor: 'pointer', boxShadow: `0 0 14px ${T.amber}44, 0 4px 12px rgba(0,0,0,0.5)`,
  display: 'grid', placeItems: 'center'
}}>?</button>;


// ──────────────────────────────────────────────────────────
// Main app
// ──────────────────────────────────────────────────────────
const PANEL_KEYS = {
  F1: 'panel-overview',
  F2: 'panel-pitch',
  F3: 'panel-valuation',
  F4: 'panel-peer',
  F5: 'panel-history'
};

const App = () => {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [activeSymbol, setActiveSymbol] = useState('TSLA');
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [activePanel, setActivePanel] = useState('F1');
  const [flashPanel, setFlashPanel] = useState(null);

  const stock = STOCKS[activeSymbol] || TSLA;
  const densityScale = tweaks.density === 'compact' ? 0.92 : tweaks.density === 'roomy' ? 1.10 : 1.0;

  // Refs for F-key panel scroll
  const refs = {
    'panel-overview': useRef(null),
    'panel-pitch': useRef(null),
    'panel-valuation': useRef(null),
    'panel-peer': useRef(null),
    'panel-history': useRef(null)
  };

  const scrollToPanel = useCallback((fkey) => {
    const id = PANEL_KEYS[fkey];
    if (!id) return;
    setActivePanel(fkey);
    setFlashPanel(id);
    setTimeout(() => setFlashPanel(null), 900);
    const el = refs[id]?.current;
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  }, []);

  const runCommand = useCallback((raw) => {
    const parts = raw.trim().replace(/^:/, '').split(/\s+/);
    const [cmd, ...args] = parts;
    if (cmd === 'open' && args[0]) {
      const s = args[0].toUpperCase();
      if (STOCKS[s] || STOCKS[args[0]]) setActiveSymbol(STOCKS[s] ? s : args[0]);
    } else if (cmd === 'theme' && args[0]) {
      const map = { amber: '#FF9500', cyan: '#22d3ee', green: '#22c55e', purple: '#a855f7' };
      if (map[args[0]]) setTweak('accent', map[args[0]]);
    }
  }, [setTweak]);

  // Global keyboard
  useEffect(() => {
    const onKey = (e) => {
      const tag = e.target?.tagName;
      const inInput = tag === 'INPUT' || tag === 'TEXTAREA';
      if (e.key === ':' && !inInput && !paletteOpen) {e.preventDefault();setPaletteOpen(true);}
      if (e.key === '?' && !inInput) {e.preventDefault();setHelpOpen((o) => !o);}
      if (e.key === 'Escape') {setPaletteOpen(false);setHelpOpen(false);}
      if (PANEL_KEYS[e.key]) {e.preventDefault();scrollToPanel(e.key);}
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [paletteOpen, scrollToPanel]);

  return (
    <div style={{
      minHeight: '100vh', background: T.bg, color: T.ink,
      fontFamily: T.font,
      fontSize: `${13 * densityScale}px`
    }}>
      <CommandBar symbol={stock.symbol} onSymbol={(s) => STOCKS[s] && setActiveSymbol(s)} activePanel={activePanel} />
      {tweaks.showTickerRail && <TickerRail tickers={MARKET_TICKERS} />}
      <div ref={refs['panel-overview']}>
        <HeroStrip stock={stock} />
        <PitchHeadline text={stock.oneLine} />
      </div>

      {/* 3-column body */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '260px minmax(0, 1fr) 380px',
        gap: 1,
        background: T.borderSoft,
        padding: 1,
        minHeight: 'calc(100vh - 290px)'
      }}>
        {/* Left: watchlist + score breakdown */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: T.borderSoft }}>
          <Watchlist active={activeSymbol} setActive={setActiveSymbol} />
          <ScoreBreakdown scores={stock.scores} />
          <QualityPanel stock={stock} />
        </div>

        {/* Center: chart + metrics + peer */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: T.borderSoft, minWidth: 0 }}>
          <ChartPanel stock={stock} accent={tweaks.accent} />
          <MetricsGrid metrics={stock.metrics} />
          <div ref={refs['panel-peer']} className={flashPanel === 'panel-peer' ? 'panel-flash' : ''}>
            <PeerPanel peers={PEERS} />
          </div>
        </div>

        {/* Right: pitch + valuation + history */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: T.borderSoft }}>
          <div ref={refs['panel-pitch']} className={flashPanel === 'panel-pitch' ? 'panel-flash' : ''}>
            <PitchPanel stock={stock} />
          </div>
          <div ref={refs['panel-valuation']} className={flashPanel === 'panel-valuation' ? 'panel-flash' : ''}>
            <ValuationPanel stock={stock} />
          </div>
          <div ref={refs['panel-history']} className={flashPanel === 'panel-history' ? 'panel-flash' : ''}>
            <HistoryPanel notes={stock.notes} />
          </div>
        </div>
      </div>

      <StatusBar stock={stock} />

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} onRun={runCommand} />
      <HelpOverlay open={helpOpen} onClose={() => setHelpOpen(false)} />
      <HelpFab onClick={() => setHelpOpen(true)} />

      <style>{`
        .panel-flash > div { animation: panelFlash 900ms ease-out; }
        @keyframes panelFlash {
          0%   { box-shadow: inset 0 0 0 1px ${T.amber}, 0 0 24px ${T.amber}88; }
          100% { box-shadow: inset 0 0 0 0px ${T.amber}, 0 0 0 ${T.amber}00; }
        }
      `}</style>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Density">
          <TweakRadio
            value={tweaks.density}
            onChange={(v) => setTweak('density', v)}
            options={[
            { value: 'compact', label: 'Compact' },
            { value: 'balanced', label: 'Balanced' },
            { value: 'roomy', label: 'Roomy' }]
            } />
          
        </TweakSection>
        <TweakSection title="Accent">
          <TweakColor
            value={tweaks.accent}
            onChange={(v) => setTweak('accent', v)}
            options={['#FF9500', '#22d3ee', '#22c55e', '#a855f7']} />
          
        </TweakSection>
        <TweakSection title="Display">
          <TweakToggle
            label="Market ticker rail"
            value={tweaks.showTickerRail}
            onChange={(v) => setTweak('showTickerRail', v)} />
          
        </TweakSection>
      </TweaksPanel>
    </div>);

};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);