/* global React */
const { useState, useEffect, useRef, useMemo } = React;

// ──────────────────────────────────────────────────────────
// Design tokens
// ──────────────────────────────────────────────────────────
const T = {
  // Bloomberg-inspired palette
  bg:       '#07090b',
  surface:  '#0d1116',
  surface2: '#141a21',
  border:   '#1f2937',
  borderSoft:'#161d25',
  ink:      '#e5e7eb',
  inkDim:   '#9ca3af',
  inkFaint: '#6b7280',
  amber:    '#FF9500',  // primary accent
  amberDim: '#cc7700',
  cyan:     '#22d3ee',
  green:    '#22c55e',
  red:      '#ef4444',
  yellow:   '#eab308',
  font: "'JetBrains Mono', ui-monospace, monospace",
};

const fmtNum = (n, opts = {}) => {
  if (!Number.isFinite(Number(n))) return '–';
  return Number(n).toLocaleString('en-US', { minimumFractionDigits: opts.dp ?? 2, maximumFractionDigits: opts.dp ?? 2 });
};
const fmtPx = (n, currency) => {
  const dp = currency === 'KRW' || currency === 'JPY' ? 0 : 2;
  return Number(n).toLocaleString('en-US', { minimumFractionDigits: dp, maximumFractionDigits: dp });
};
const sign = (n) => (n > 0 ? '+' : n < 0 ? '' : '');
const colorForChange = (n) => (n > 0 ? T.green : n < 0 ? T.red : T.inkDim);

// ──────────────────────────────────────────────────────────
// Small pieces
// ──────────────────────────────────────────────────────────
const Cell = ({ label, children, accent, style }) => (
  <div style={{
    border: `1px solid ${T.border}`,
    background: T.surface,
    position: 'relative',
    ...style,
  }}>
    {label && (
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        height: 22,
        padding: '0 10px',
        borderBottom: `1px solid ${T.borderSoft}`,
        background: T.surface2,
        fontSize: 9.5, fontWeight: 700, letterSpacing: '0.12em',
        color: accent || T.inkFaint,
        textTransform: 'uppercase',
      }}>
        {accent && <span style={{ width: 4, height: 4, background: accent, borderRadius: 1 }}/>}
        {label}
      </div>
    )}
    {children}
  </div>
);

const Stat = ({ label, value, sub, color, align = 'left' }) => (
  <div style={{ textAlign: align, minWidth: 0 }}>
    <div style={{ fontSize: 9.5, color: T.inkFaint, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 3 }}>
      {label}
    </div>
    <div style={{ fontSize: 16, fontWeight: 700, color: color || T.ink, lineHeight: 1.1, fontVariantNumeric: 'tabular-nums' }}>
      {value}
    </div>
    {sub && (
      <div style={{ fontSize: 10.5, color: T.inkDim, marginTop: 3, fontVariantNumeric: 'tabular-nums' }}>
        {sub}
      </div>
    )}
  </div>
);

// Score ring with halo
const ScoreRing = ({ score, size = 64, accent = T.amber, label = 'SCORE' }) => {
  const r = size / 2 - 4;
  const c = 2 * Math.PI * r;
  const dash = (c * Math.max(0, Math.min(100, score))) / 100;
  return (
    <div style={{ position: 'relative', width: size, height: size, flex: '0 0 auto' }}>
      <svg width={size} height={size} style={{ display: 'block' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={T.border} strokeWidth="3" />
        <circle cx={size/2} cy={size/2} r={r} fill="none"
          stroke={accent} strokeWidth="3"
          strokeDasharray={`${dash} ${c}`}
          strokeLinecap="round"
          transform={`rotate(-90 ${size/2} ${size/2})`}
          style={{ filter: `drop-shadow(0 0 4px ${accent}99)` }}/>
      </svg>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex',
        flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{ fontSize: size * 0.32, fontWeight: 700, color: T.ink, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>
          {score}
        </div>
        <div style={{ fontSize: 7.5, color: T.inkFaint, letterSpacing: '0.15em', marginTop: 2 }}>
          {label}
        </div>
      </div>
    </div>
  );
};

// Bar
const ScoreBar = ({ pct, color, height = 5 }) => (
  <div style={{ width: '100%', height, background: T.border, borderRadius: 1, position: 'relative', overflow: 'hidden' }}>
    <div style={{
      width: `${Math.max(0, Math.min(100, pct))}%`, height: '100%',
      background: color, borderRadius: 1,
      boxShadow: `0 0 6px ${color}66`,
    }}/>
  </div>
);

// Sparkline
const Spark = ({ data, width = 100, height = 24, color = T.amber, fill = true }) => {
  if (!data?.length) return null;
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const w = width, h = height;
  const pts = data.map((v, i) => [
    (i / (data.length - 1)) * (w - 2) + 1,
    h - 2 - ((v - min) / range) * (h - 4),
  ]);
  const path = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
  const area = `${path} L ${w-1} ${h-1} L 1 ${h-1} Z`;
  return (
    <svg width={w} height={h} style={{ display: 'block' }}>
      {fill && <path d={area} fill={color} opacity="0.12"/>}
      <path d={path} fill="none" stroke={color} strokeWidth="1.4" strokeLinejoin="round" strokeLinecap="round"/>
    </svg>
  );
};

// Full chart
const PriceChart = ({ data, height = 200, accent = T.amber, height2 }) => {
  const ref = useRef(null);
  const [w, setW] = useState(0);
  useEffect(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver((e) => setW(e[0].contentRect.width));
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const padded = max - min;
  const top = max + padded * 0.1, bot = min - padded * 0.1;
  const pad = { l: 50, r: 12, t: 10, b: 22 };
  const cw = Math.max(1, w - pad.l - pad.r);
  const ch = height - pad.t - pad.b;
  const pts = data.map((v, i) => [
    pad.l + (i / (data.length - 1)) * cw,
    pad.t + ((top - v) / (top - bot)) * ch,
  ]);
  const path = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p[0].toFixed(2)} ${p[1].toFixed(2)}`).join(' ');
  const area = pts.length ? `${path} L ${pad.l + cw} ${pad.t + ch} L ${pad.l} ${pad.t + ch} Z` : '';
  const yTicks = useMemo(() => {
    const ticks = [];
    for (let i = 0; i <= 4; i++) {
      const v = top - ((top - bot) * i) / 4;
      ticks.push(v);
    }
    return ticks;
  }, [top, bot]);
  const xLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May'];

  return (
    <div ref={ref} style={{ width: '100%', height, position: 'relative' }}>
      {w > 0 && (
        <svg width={w} height={height} style={{ display: 'block' }}>
          <defs>
            <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={accent} stopOpacity="0.30"/>
              <stop offset="100%" stopColor={accent} stopOpacity="0"/>
            </linearGradient>
          </defs>
          {yTicks.map((v, i) => {
            const y = pad.t + ((top - v) / (top - bot)) * ch;
            return (
              <g key={i}>
                <line x1={pad.l} x2={pad.l + cw} y1={y} y2={y} stroke={T.border} strokeWidth="0.6" strokeDasharray="2 3" opacity="0.7"/>
                <text x={pad.l - 6} y={y + 3} textAnchor="end" fontSize="9" fill={T.inkFaint} fontFamily={T.font}>
                  {v >= 1000 ? v.toFixed(0) : v.toFixed(1)}
                </text>
              </g>
            );
          })}
          {xLabels.map((lbl, i) => {
            const x = pad.l + (i / (xLabels.length - 1)) * cw;
            return (
              <text key={i} x={x} y={height - 6} textAnchor="middle" fontSize="9" fill={T.inkFaint} fontFamily={T.font}>{lbl}</text>
            );
          })}
          <path d={area} fill="url(#chartFill)"/>
          <path d={path} fill="none" stroke={accent} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 3px ${accent}aa)` }}/>
          {/* last point dot */}
          {pts.length > 0 && (() => {
            const [lx, ly] = pts[pts.length - 1];
            return (
              <g>
                <circle cx={lx} cy={ly} r="3" fill={accent}/>
                <line x1={pad.l} x2={pad.l + cw} y1={ly} y2={ly} stroke={accent} strokeWidth="0.6" strokeDasharray="3 3" opacity="0.5"/>
              </g>
            );
          })()}
        </svg>
      )}
    </div>
  );
};

// ──────────────────────────────────────────────────────────
// Top: command bar + ticker rail
// ──────────────────────────────────────────────────────────
const CommandBar = ({ symbol, onSymbol, activePanel = 'F1' }) => {
  const [val, setVal] = useState(symbol);
  useEffect(() => { setVal(symbol); }, [symbol]);
  const fkeys = [
    { k: 'F1', label: 'OVR' },
    { k: 'F2', label: 'PITCH' },
    { k: 'F3', label: 'VAL' },
    { k: 'F4', label: 'PEER' },
    { k: 'F5', label: 'HX' },
  ];
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: 18,
      height: 36,
      padding: '0 14px',
      background: T.surface,
      borderBottom: `1px solid ${T.border}`,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: '0 0 auto' }}>
        <div style={{
          width: 18, height: 18, background: T.amber,
          display: 'grid', placeItems: 'center',
          fontSize: 11, fontWeight: 800, color: '#000',
          boxShadow: `0 0 10px ${T.amber}88`,
        }}>T</div>
        <span style={{ fontWeight: 700, color: T.amber, fontSize: 12, letterSpacing: '0.14em' }}>
          THESIS//TRACK
        </span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: '0 1 auto', minWidth: 0 }}>
        <span style={{ color: T.amber, fontWeight: 700, flex: '0 0 auto' }}>&gt;</span>
        <input
          value={val}
          onChange={(e) => setVal(e.target.value.toUpperCase())}
          onKeyDown={(e) => { if (e.key === 'Enter') onSymbol?.(val); }}
          style={{
            background: 'transparent', border: 0, outline: 0,
            color: T.amber, fontFamily: T.font, fontSize: 13, fontWeight: 600,
            width: 110, padding: 0, letterSpacing: '0.05em',
          }}
        />
      </div>
      <div className="cmd-hints" style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: 10.5, color: T.inkFaint, flex: '0 0 auto' }}>
        <span><kbd style={kbdStyle}>:</kbd>cmd</span>
        <span><kbd style={kbdStyle}>/</kbd>find</span>
      </div>
      <div className="cmd-fkeys" style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 10.5, flex: '0 0 auto' }}>
        {fkeys.map(f => {
          const on = activePanel === f.k;
          return (
            <span key={f.k} style={{ color: on ? T.amber : T.inkDim, fontWeight: on ? 700 : 500 }}>
              <kbd style={kbdStyle}>{f.k}</kbd>{f.label}
            </span>
          );
        })}
      </div>
      <div style={{ flex: '1 1 auto' }}/>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 10.5, color: T.inkFaint, flex: '0 0 auto' }}>
        <Pulse/>
        <span>LIVE · 16:42 KST</span>
      </div>
      <style>{`
        @keyframes tt-pulse { 0% { transform: scale(1); opacity: 0.7; } 100% { transform: scale(2.5); opacity: 0; } }
        @media (max-width: 1180px) { .cmd-fkeys { display: none !important; } }
        @media (max-width: 880px)  { .cmd-hints { display: none !important; } }
      `}</style>
    </div>
  );
};

const kbdStyle = {
  display: 'inline-block',
  padding: '1px 5px',
  background: T.surface2,
  border: `1px solid ${T.border}`,
  borderRadius: 2,
  fontSize: 10,
  fontFamily: T.font,
  color: T.inkDim,
  margin: '0 2px',
};

const Pulse = () => (
  <span style={{ position: 'relative', display: 'inline-block', width: 7, height: 7, flex: '0 0 auto' }}>
    <span style={{
      position: 'absolute', inset: 0, background: T.green, borderRadius: '50%',
      animation: 'tt-pulse 1.8s ease-out infinite',
    }}/>
    <span style={{ position: 'absolute', inset: 1, background: T.green, borderRadius: '50%' }}/>
  </span>
);

const TickerRail = ({ tickers }) => (
  <div style={{
    height: 26,
    display: 'flex', alignItems: 'center', gap: 0,
    background: T.bg,
    borderBottom: `1px solid ${T.border}`,
    overflow: 'hidden',
  }}>
    {tickers.map((t, i) => (
      <div key={i} style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '0 14px',
        borderRight: `1px solid ${T.borderSoft}`,
        fontSize: 10.5,
        fontVariantNumeric: 'tabular-nums',
      }}>
        <span style={{ color: T.inkDim, fontWeight: 600 }}>{t.symbol}</span>
        <span style={{ color: T.ink }}>{t.val}</span>
        <span style={{ color: colorForChange(t.change), fontWeight: 600 }}>
          {sign(t.change)}{t.change.toFixed(2)}%
        </span>
      </div>
    ))}
  </div>
);

// ──────────────────────────────────────────────────────────
// Hero strip + pitch headline
// ──────────────────────────────────────────────────────────
const HeroStrip = ({ stock }) => {
  const change = stock.price - stock.prevClose;
  const changePct = (change / stock.prevClose) * 100;
  const upside = ((stock.target - stock.price) / stock.price) * 100;
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'auto 1.2fr 1fr 1fr 1.2fr 0.9fr 1fr',
      gap: 0,
      padding: '14px 18px',
      background: `linear-gradient(180deg, ${T.surface} 0%, ${T.bg} 100%)`,
      borderBottom: `1px solid ${T.border}`,
      alignItems: 'center',
    }}>
      <ScoreRing score={stock.scores.overall} size={68} accent={T.amber}/>
      {/* Symbol */}
      <div style={{ paddingLeft: 16, paddingRight: 16, borderRight: `1px solid ${T.borderSoft}` }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
          <span style={{ fontSize: 22, fontWeight: 800, color: T.ink, letterSpacing: '0.02em' }}>
            {stock.symbol}
          </span>
          <span style={{ fontSize: 14 }}>{stock.flag}</span>
          <span style={{
            fontSize: 9, padding: '2px 6px', border: `1px solid ${T.amber}`,
            color: T.amber, fontWeight: 700, letterSpacing: '0.1em',
          }}>{stock.recommendation.toUpperCase()}</span>
        </div>
        <div style={{ fontSize: 11, color: T.inkDim }}>
          {stock.name} · {stock.market} · {stock.currency}
        </div>
      </div>
      <div style={{ paddingLeft: 18, paddingRight: 18, borderRight: `1px solid ${T.borderSoft}` }}>
        <Stat
          label="Last Price"
          value={`$${fmtPx(stock.price, stock.currency)}`}
          sub={
            <span style={{ color: colorForChange(change) }}>
              {sign(change)}{change.toFixed(2)} ({sign(changePct)}{changePct.toFixed(2)}%)
            </span>
          }
        />
      </div>
      <div style={{ paddingLeft: 18, paddingRight: 18, borderRight: `1px solid ${T.borderSoft}` }}>
        <Stat
          label="Target · Upside"
          value={`$${fmtPx(stock.target, stock.currency)}`}
          sub={<span style={{ color: colorForChange(upside) }}>{sign(upside)}{upside.toFixed(2)}%</span>}
        />
      </div>
      <div style={{ paddingLeft: 18, paddingRight: 18, borderRight: `1px solid ${T.borderSoft}` }}>
        <div style={{ fontSize: 9.5, color: T.inkFaint, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 4 }}>
          Bull · Base · Bear
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'baseline', fontVariantNumeric: 'tabular-nums' }}>
          <span style={{ color: T.green, fontSize: 14, fontWeight: 700 }}>${stock.valuation.bull.price}</span>
          <span style={{ color: T.inkFaint }}>·</span>
          <span style={{ color: T.amber, fontSize: 14, fontWeight: 700 }}>${stock.valuation.base.price}</span>
          <span style={{ color: T.inkFaint }}>·</span>
          <span style={{ color: T.red, fontSize: 14, fontWeight: 700 }}>${stock.valuation.bear.price}</span>
        </div>
        <div style={{ fontSize: 10, color: T.inkDim, marginTop: 4 }}>
          PER 70x · base
        </div>
      </div>
      <div style={{ paddingLeft: 18, paddingRight: 18, borderRight: `1px solid ${T.borderSoft}` }}>
        <Stat
          label="Next Review"
          value={<span style={{ color: T.cyan }}>D-{stock.review.daysLeft}</span>}
          sub={stock.review.next}
        />
      </div>
      <div style={{ paddingLeft: 18 }}>
        <div style={{ fontSize: 9.5, color: T.inkFaint, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 4 }}>
          Score Trend · 12M
        </div>
        <Spark data={stock.scoreHistory} width={140} height={26} color={T.amber}/>
        <div style={{ fontSize: 10, color: T.inkDim, marginTop: 3, fontVariantNumeric: 'tabular-nums' }}>
          {stock.scoreHistory[0]} → {stock.scoreHistory[stock.scoreHistory.length-1]}
          <span style={{ color: T.red, marginLeft: 8 }}>
            {stock.scoreHistory[stock.scoreHistory.length-1] - stock.scoreHistory[0]}
          </span>
        </div>
      </div>
    </div>
  );
};

const PitchHeadline = ({ text }) => (
  <div style={{
    padding: '14px 22px',
    background: T.bg,
    borderBottom: `1px solid ${T.border}`,
    display: 'flex', alignItems: 'center', gap: 14,
  }}>
    <div style={{
      fontSize: 9, color: T.amber, letterSpacing: '0.18em', fontWeight: 700,
      writingMode: 'vertical-rl', transform: 'rotate(180deg)',
    }}>PITCH</div>
    <div style={{ width: 2, alignSelf: 'stretch', background: T.amber, boxShadow: `0 0 8px ${T.amber}88` }}/>
    <div style={{
      fontFamily: "'Inter', sans-serif",
      fontSize: 19, fontWeight: 500, color: T.ink, lineHeight: 1.4,
      letterSpacing: '-0.01em',
      flex: 1,
    }}>
      "{text}"
    </div>
  </div>
);

window.T = T;
window.Cell = Cell;
window.Stat = Stat;
window.ScoreRing = ScoreRing;
window.ScoreBar = ScoreBar;
window.Spark = Spark;
window.PriceChart = PriceChart;
window.CommandBar = CommandBar;
window.TickerRail = TickerRail;
window.HeroStrip = HeroStrip;
window.PitchHeadline = PitchHeadline;
window.fmtNum = fmtNum;
window.fmtPx = fmtPx;
window.sign = sign;
window.colorForChange = colorForChange;
