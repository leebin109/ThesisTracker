/* global */
// Sample data borrowed from the original ThesisTrack app
const TSLA = {
  symbol: 'TSLA',
  name: 'Tesla, Inc.',
  market: 'NASDAQ',
  currency: 'USD',
  flag: '🇺🇸',
  recommendation: 'Watch',
  oneLine: '전기차 마진보다 자율주행과 에너지 사업의 실제 확인이 핵심이다.',
  keyQuestion: 'FSD와 에너지 저장장치가 자동차 마진 둔화를 상쇄할 수 있는가?',
  thesis: [
    '에너지 저장장치 매출이 성장 축으로 부상하고 있다.',
    'FSD 기대가 밸류에이션을 지지하지만 실적 기여는 아직 확인이 필요하다.',
    '자동차 마진 안정화가 먼저 확인되어야 한다.',
  ],
  catalysts: ['FSD 지표 공개', '에너지 부문 마진 개선', '신차 출시 일정'],
  risks: ['가격 인하 경쟁', '높은 밸류에이션', '규제 및 안전성 이슈'],
  variantView: '시장은 FSD를 크게 반영하지만 에너지 부문의 안정적 이익 기여는 덜 반영할 수 있다.',
  numbersToWatch: ['자동차 gross margin', '에너지 매출 성장률', 'FCF 마진', '인도량 성장률'],
  changeMind: 'FCF 마진이 회복되지 않거나 인도량 성장률이 둔화되면 Watch 의견을 낮춘다.',
  price: 253.40,
  prevClose: 250.36,
  target: 280,
  metrics: {
    per: 72.6, pbr: 9.8, roe: 12.1, opMargin: 7.4,
    debtRatio: 17, revGrowth: 8.7, epsGrowth: -22.4,
    currentRatio: 173, fcfMargin: 4.8,
  },
  asOf: '2025-12-31', source: 'SEC EDGAR',
  scores: {
    overall: 44,
    profitability: 41, stability: 88, growth: 24, valuation: 0, risk: 78,
    weights: { profitability: 25, stability: 25, growth: 20, valuation: 20, risk: 10 },
  },
  scoreHistory: [52, 51, 49, 50, 48, 47, 46, 48, 47, 45, 46, 44],
  priceHistory: [214, 226, 221, 238, 245, 232, 251, 263, 256, 272, 267, 280, 275, 268, 253],
  valuation: {
    bear: { driver: 3, multiple: 45, mos: 10, price: 121.5 },
    base: { driver: 4, multiple: 70, mos: 0, price: 280 },
    bull: { driver: 5, multiple: 85, mos: 0, price: 425 },
    note: '높은 멀티플은 FSD와 에너지 성장 가정이 확인될 때 정당화된다.',
  },
  review: { next: '2026-05-31', cadence: 30, daysLeft: 24 },
  quality: [
    { kind: 'ok', text: '재무 기준일 2025-12-31 (4개월 경과)' },
    { kind: 'warn', text: 'EPS 성장 전기 대비 -22.4% — 추적 필요' },
    { kind: 'ok', text: '가격 출처 FMP · 실시간' },
    { kind: 'warn', text: 'PER 72.6x — 적자 종목 해석 주의' },
    { kind: 'info', text: '다음 리뷰 D-24 (5월 31일)' },
  ],
  notes: [
    { date: '2026-04-18', kind: '실적', text: '마진 회복 전까지는 밸류에이션 부담을 별도로 추적.', source: '' },
    { date: '2026-03-22', kind: '공시', text: 'Q1 인도량 발표 — 컨센서스 부합.', source: 'https://ir.tesla.com' },
    { date: '2026-02-04', kind: '뉴스', text: 'FSD v13 베타 공개. 안전 지표 자체 발표.', source: '' },
  ],
};

const PEERS = [
  { symbol: 'TSLA', name: 'Tesla', per: 72.6, pbr: 9.8, roe: 12.1, debt: 17, score: 44, active: true },
  { symbol: 'AAPL', name: 'Apple', per: 29.4, pbr: 36.2, roe: 156, debt: 145, score: 68 },
  { symbol: '005930', name: '삼성전자', per: 18.4, pbr: 1.3, roe: 7.6, debt: 27, score: 71 },
  { symbol: 'NVDA', name: 'NVIDIA', per: 65.2, pbr: 24.1, roe: 91.0, debt: 12, score: 82 },
  { symbol: '7203', name: 'Toyota', per: 9.2, pbr: 1.0, roe: 10.9, debt: 95, score: 65 },
];

const WATCHLIST = [
  { symbol: 'TSLA', name: 'Tesla', score: 44, change: 1.21, price: 253.40, currency: 'USD', flag: '🇺🇸', active: true },
  { symbol: 'AAPL', name: 'Apple', score: 68, change: -0.42, price: 212.05, currency: 'USD', flag: '🇺🇸' },
  { symbol: '005930', name: '삼성전자', score: 71, change: 0.79, price: 76400, currency: 'KRW', flag: '🇰🇷' },
  { symbol: 'NVDA', name: 'NVIDIA', score: 82, change: 2.13, price: 142.18, currency: 'USD', flag: '🇺🇸' },
  { symbol: '7203', name: 'Toyota', score: 65, change: 0.31, price: 2847, currency: 'JPY', flag: '🇯🇵' },
  { symbol: 'MSFT', name: 'Microsoft', score: 75, change: 0.0, price: 418.20, currency: 'USD', flag: '🇺🇸' },
  { symbol: '000660', name: 'SK하이닉스', score: 69, change: 1.51, price: 198000, currency: 'KRW', flag: '🇰🇷' },
  { symbol: 'META', name: 'Meta', score: 58, change: -1.14, price: 521.40, currency: 'USD', flag: '🇺🇸' },
  { symbol: 'JPM', name: 'JPMorgan', score: 73, change: 0.42, price: 218.30, currency: 'USD', flag: '🇺🇸' },
  { symbol: 'GOOGL', name: 'Alphabet', score: 80, change: 0.91, price: 178.20, currency: 'USD', flag: '🇺🇸' },
];

const MARKET_TICKERS = [
  { symbol: 'KOSPI', val: '2,712.40', change: 0.52 },
  { symbol: 'S&P', val: '5,182.45', change: 0.21 },
  { symbol: 'NDX', val: '17,890.20', change: 0.84 },
  { symbol: 'N225', val: '38,442.10', change: -0.31 },
  { symbol: 'USDKRW', val: '1,376.20', change: -0.12 },
  { symbol: 'WTI', val: '78.42', change: 1.12 },
  { symbol: 'BTC', val: '94,210', change: 2.41 },
  { symbol: 'US10Y', val: '4.382%', change: -0.04 },
];

const AAPL = {
  symbol: 'AAPL', name: 'Apple Inc.', market: 'NASDAQ', currency: 'USD', flag: '🇺🇸',
  recommendation: 'Hold',
  oneLine: '서비스 매출과 자사주 매입이 받쳐주지만, 신규 성장 동력이 약하다.',
  keyQuestion: 'AI 기능과 Vision Pro가 iPhone 매출 정체를 보완할 수 있는가?',
  thesis: [
    '서비스 매출 마진이 전체 수익성을 견인하고 있다.',
    '하드웨어 매출은 성숙기 진입, 교체 사이클 길어지는 중.',
    'AI 통합과 자사주 매입이 EPS를 방어한다.',
  ],
  catalysts: ['Apple Intelligence 확대', '서비스 매출 두 자릿수 성장', '인도/신흥국 점유율'],
  risks: ['중국 규제 및 매출 둔화', 'iPhone 교체 사이클 장기화', '반독점 소송'],
  variantView: '시장은 AI 효과를 빠르게 반영하지만, 실제 매출 기여는 2027년 이후일 수 있다.',
  numbersToWatch: ['서비스 매출 성장률', 'iPhone ASP', '중국 매출', '자사주 매입 규모'],
  changeMind: '서비스 매출 성장률이 한 자릿수로 떨어지면 의견 하향.',
  price: 212.05, prevClose: 212.94, target: 235,
  metrics: { per: 29.4, pbr: 36.2, roe: 156, opMargin: 31.5, debtRatio: 145, revGrowth: 5.2, epsGrowth: 9.4, currentRatio: 95, fcfMargin: 26.1 },
  asOf: '2025-09-30', source: 'SEC EDGAR',
  scores: { overall: 68, profitability: 92, stability: 70, growth: 38, valuation: 45, risk: 82, weights: { profitability: 25, stability: 25, growth: 20, valuation: 20, risk: 10 } },
  scoreHistory: [70, 71, 70, 69, 68, 67, 68, 69, 70, 69, 68, 68],
  priceHistory: [188, 192, 198, 205, 201, 208, 215, 218, 212, 220, 224, 218, 215, 211, 212],
  valuation: {
    bear: { driver: 6.2, multiple: 22, mos: 10, price: 122.8 },
    base: { driver: 7.0, multiple: 28, mos: 0,  price: 196 },
    bull: { driver: 7.8, multiple: 32, mos: 0,  price: 250 },
    note: '서비스 매출 비중이 30%를 넘으면 멀티플 재평가 가능.',
  },
  review: { next: '2026-06-15', cadence: 60, daysLeft: 38 },
  quality: [
    { kind: 'ok',   text: '재무 기준일 2025-09-30 (회계연도 종료)' },
    { kind: 'info', text: 'EPS 성장 전기 대비 +9.4% — 안정적' },
    { kind: 'ok',   text: '가격 출처 FMP · 실시간' },
    { kind: 'info', text: '다음 리뷰 D-38' },
  ],
  notes: [
    { date: '2026-04-30', kind: '실적', text: 'Q2 서비스 매출 +14% YoY, 시장 예상 부합.', source: 'https://www.apple.com/newsroom' },
    { date: '2026-03-12', kind: '뉴스', text: 'Apple Intelligence 인도 출시. 현지화 가속.', source: '' },
    { date: '2026-01-25', kind: '공시', text: '$110B 자사주 매입 프로그램 발표.', source: '' },
  ],
};

const NVDA = {
  symbol: 'NVDA', name: 'NVIDIA Corporation', market: 'NASDAQ', currency: 'USD', flag: '🇺🇸',
  recommendation: 'Buy',
  oneLine: 'AI 인프라 투자 사이클의 정점, 그러나 경쟁사 대안 등장이 가까워졌다.',
  keyQuestion: 'CUDA moat가 ASIC/맞춤형 칩 등장 후에도 유지되는가?',
  thesis: [
    '데이터센터 GPU 수요가 향후 2년간 공급을 초과한다.',
    'CUDA 생태계가 진입 장벽을 형성한다.',
    '하이퍼스케일러 자체 칩은 위협이지만 단기 영향은 제한적.',
  ],
  catalysts: ['Blackwell 출하 확대', '엔터프라이즈 AI 도입', 'Sovereign AI 수주'],
  risks: ['고객사 자체 칩 (Trainium, TPU)', '중국 수출 규제', '높은 멀티플'],
  variantView: '시장은 향후 4년의 성장을 가격에 반영했다. 둔화 신호 한 분기면 큰 조정 가능.',
  numbersToWatch: ['데이터센터 매출 QoQ', '게임 매출', 'Capex 가이던스 (고객사)', '재고 일수'],
  changeMind: '데이터센터 매출이 QoQ 감소하면 즉시 비중 축소 검토.',
  price: 142.18, prevClose: 139.23, target: 165,
  metrics: { per: 65.2, pbr: 24.1, roe: 91.0, opMargin: 62.4, debtRatio: 12, revGrowth: 78.4, epsGrowth: 124.5, currentRatio: 412, fcfMargin: 49.8 },
  asOf: '2026-01-31', source: 'SEC EDGAR',
  scores: { overall: 82, profitability: 96, stability: 85, growth: 98, valuation: 35, risk: 65, weights: { profitability: 25, stability: 25, growth: 20, valuation: 20, risk: 10 } },
  scoreHistory: [78, 79, 80, 81, 82, 83, 84, 83, 82, 82, 82, 82],
  priceHistory: [98, 105, 112, 118, 124, 132, 138, 145, 142, 148, 152, 146, 144, 140, 142],
  valuation: {
    bear: { driver: 2.8, multiple: 35, mos: 15, price: 83.3 },
    base: { driver: 3.6, multiple: 50, mos: 0,  price: 180 },
    bull: { driver: 4.5, multiple: 60, mos: 0,  price: 270 },
    note: 'PER 50x는 데이터센터 매출 +40% YoY 가정.',
  },
  review: { next: '2026-05-22', cadence: 30, daysLeft: 14 },
  quality: [
    { kind: 'ok',   text: '재무 기준일 2026-01-31 (FY26 Q4)' },
    { kind: 'warn', text: 'PER 65x — 멀티플 압축 위험' },
    { kind: 'ok',   text: '가격 출처 FMP · 실시간' },
    { kind: 'info', text: '다음 리뷰 D-14 (5월 22일)' },
  ],
  notes: [
    { date: '2026-04-25', kind: '뉴스', text: 'Blackwell B200 양산 정상화, 공급 부족 완화.', source: '' },
    { date: '2026-03-18', kind: '실적', text: 'Q4 데이터센터 매출 +112% YoY. 가이던스 상향.', source: '' },
    { date: '2026-02-14', kind: '공시', text: 'Sovereign AI 수주 — 사우디, UAE 발표.', source: '' },
  ],
};

const SAMSUNG = {
  symbol: '005930', name: '삼성전자', market: 'KOSPI', currency: 'KRW', flag: '🇰🇷',
  recommendation: 'Buy',
  oneLine: 'HBM 사이클과 비메모리 마진 회복이 동시에 일어나는 변곡점이다.',
  keyQuestion: 'HBM3E 양산 수율과 파운드리 고객사 확보가 동시에 진행되는가?',
  thesis: [
    '메모리 가격 사이클 상승 국면 진입.',
    'HBM에서는 SK하이닉스 대비 후발주자, 따라잡기 진행 중.',
    '파운드리 적자 축소가 밸류에이션 재평가의 핵심.',
  ],
  catalysts: ['HBM3E 엔비디아 퀄 통과', '메모리 ASP 상승', '파운드리 신규 수주'],
  risks: ['중국 메모리 추격 (CXMT)', '환율 변동성', '파운드리 적자 지속'],
  variantView: '시장은 HBM 점유율 회복을 의심하지만, 양산 수율 정상화 시 가파른 재평가 가능.',
  numbersToWatch: ['HBM 매출', '메모리 OP 마진', '파운드리 가동률', '재고 일수'],
  changeMind: 'HBM3E 양산 차질 시 비중 축소.',
  price: 76400, prevClose: 75800, target: 92000,
  metrics: { per: 18.4, pbr: 1.3, roe: 7.6, opMargin: 12.8, debtRatio: 27, revGrowth: 14.2, epsGrowth: 41.2, currentRatio: 220, fcfMargin: 8.4 },
  asOf: '2025-12-31', source: 'DART',
  scores: { overall: 71, profitability: 65, stability: 82, growth: 72, valuation: 78, risk: 70, weights: { profitability: 25, stability: 25, growth: 20, valuation: 20, risk: 10 } },
  scoreHistory: [62, 64, 65, 66, 68, 69, 70, 71, 72, 71, 71, 71],
  priceHistory: [62000, 64500, 67000, 69500, 71000, 73000, 75500, 78000, 76000, 79000, 81000, 78500, 77200, 76800, 76400],
  valuation: {
    bear: { driver: 3500, multiple: 12, mos: 10, price: 37800 },
    base: { driver: 4500, multiple: 18, mos: 0,  price: 81000 },
    bull: { driver: 5800, multiple: 22, mos: 0,  price: 127600 },
    note: 'HBM 매출 비중 15% 도달 시 멀티플 재평가.',
  },
  review: { next: '2026-05-30', cadence: 45, daysLeft: 22 },
  quality: [
    { kind: 'ok',   text: '재무 기준일 2025-12-31 (FY25)' },
    { kind: 'ok',   text: 'EPS 성장 전기 대비 +41.2% — 사이클 회복' },
    { kind: 'info', text: '가격 출처 KIS · 15분 지연' },
    { kind: 'info', text: '다음 리뷰 D-22' },
  ],
  notes: [
    { date: '2026-04-28', kind: '실적', text: 'Q1 OP 6.6조원, 컨센서스 부합. 메모리 견인.', source: 'https://www.samsung.com' },
    { date: '2026-03-08', kind: '뉴스', text: 'HBM3E 12단 NVIDIA 퀄 진행 중 — 5월 결과 예상.', source: '' },
    { date: '2026-02-01', kind: '공시', text: '파운드리 2nm 신규 고객사 확보 발표.', source: '' },
  ],
};

const STOCKS = { TSLA, AAPL, NVDA, '005930': SAMSUNG };

window.TSLA = TSLA;
window.AAPL = AAPL;
window.NVDA = NVDA;
window.SAMSUNG = SAMSUNG;
window.STOCKS = STOCKS;
window.PEERS = PEERS;
window.WATCHLIST = WATCHLIST;
window.MARKET_TICKERS = MARKET_TICKERS;
